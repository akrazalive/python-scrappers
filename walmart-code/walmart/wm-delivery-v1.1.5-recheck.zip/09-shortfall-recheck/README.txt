198 listings that failed source-count reconciliation were re-queued from page 1 (recheck_shortfall.py - a helper
outside the scraper source, so the source hash is unchanged) and re-read in the SAME run on the SAME hash.
recheck-before-after.csv: per listing, Walmart's total and products seen on the first read and on the re-check.
