"""Re-check the listings that failed source-count reconciliation in a finished run.

Re-queues ONLY those listings (from page 1, counters reset), logs a `shortfall_recheck` event in the run's own
checkpoint, and re-opens the run so the normal command resumes it:

    python recheck_shortfall.py --scraper-dir <walmart-scraper folder> --run-id 20261024T043517Z-fa478c
    cd <walmart-scraper folder> && python -m wmscraper run --location walmart-100-bentonville --max-requests 3000

Products already collected stay in the checkpoint (de-duplicated by item id); each re-read listing gets a fresh
`seen` count, which is what reconciliation compares with Walmart's reported total.
Use --dry-run first to see what would be re-queued. This file is NOT part of the scraper source (hash unchanged).
"""
import argparse
import json
import sqlite3
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("--scraper-dir", required=True)
ap.add_argument("--run-id", required=True)
ap.add_argument("--location", default="walmart-100-bentonville")
ap.add_argument("--ratio", type=float, default=0.95)
ap.add_argument("--tolerance", type=int, default=2)
ap.add_argument("--full-page-min-items", type=int, default=20)
ap.add_argument("--dry-run", action="store_true")
a = ap.parse_args()

root = Path(a.scraper_dir) / "output" / a.location
ckpt = root / "runs" / a.run_id / "checkpoint.sqlite"
assert ckpt.exists(), f"checkpoint not found: {ckpt}"
db = sqlite3.connect(ckpt)
assert db.execute("PRAGMA quick_check").fetchone()[0] == "ok", "checkpoint integrity check failed - stop"

rows = db.execute("SELECT category, sub_category, url, reported_total, page_size, seen, stop_reason, next_page "
                  "FROM listings WHERE status='done'").fetchall()
short = []
for cat, sub, url, rep, ps, seen, stop, nxt in rows:
    if not rep or not ps:
        continue
    reach = min(rep, 25 * ps)
    if seen >= a.ratio * reach or reach - seen <= a.tolerance:
        continue
    if stop == "walmart_served_no_more_products" or ps < a.full_page_min_items:
        continue  # reported as "Walmart count not backed by products", not a failure
    short.append({"category": cat, "sub_category": sub, "url": url, "walmart_total": rep, "seen_before": seen,
                  "pages_before": nxt - 1})

pages = sum(s["pages_before"] for s in short)
print(f"{len(short)} listings to re-check, ~{pages} pages (~{pages} provider requests)")
for s in short[:10]:
    print("  ", s["category"], "/", s["sub_category"], s["seen_before"], "of", s["walmart_total"])
if a.dry_run:
    raise SystemExit(0)

with db:
    for s in short:
        db.execute("UPDATE listings SET status='pending', next_page=1, seen=0, kept=0, capped=0, store_available=0, "
                   "store_oos=0, zero_streak=0, stop_reason='', error='' WHERE category=? AND url=?",
                   (s["category"], s["url"]))
    db.execute("INSERT INTO events(kind, detail) VALUES ('shortfall_recheck', ?)",
               (json.dumps({"listings": len(short), "pages_before": pages, "items": short}),))
    # the identity step must not re-run its whole queue: only items new to the run will be unenriched (0)
state_p = root / "state.json"
state = json.loads(state_p.read_text()) if state_p.exists() else {}
state["open_run"] = a.run_id
state_p.write_text(json.dumps(state, indent=2))
(Path(a.scraper_dir) / f"recheck-{a.run_id}.json").write_text(json.dumps(short, indent=1, ensure_ascii=False))
print(f"re-queued {len(short)} listings; run {a.run_id} re-opened. Now run:\n"
      f"  python -m wmscraper run --location {a.location} --max-requests 3000")
