OFFLINE automated tests on synthetic fixture pages (NOT Walmart data, NOT live results).
