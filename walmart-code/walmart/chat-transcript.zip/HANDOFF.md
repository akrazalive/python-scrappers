# Walmart store #100 scraper: handoff for the 198-listing re-check

You are taking over a Walmart scraper for the Freelancer contest "Robust Walmart Scraper for Azure Environment" (entries #32 / #38). The client is Darren. The contest closes on **24 Oct 2026**. This file covers what was done, where everything is, and exactly how to run the one remaining step.

---

## 1. What is in this folder

| Path | What it is |
|---|---|
| `walmart-scraper-1.1.5-src.zip` | Scraper source, **v1.1.5**, source_sha256 `75d76e0ee62a06e8bfaf48b245852463f08528537099f35a99fbfffcc3e343cc` |
| `output/walmart-100-bentonville/runs/20261024T043517Z-fa478c/` | The **full live run** of store #100: `checkpoint.sqlite` (all state), `records.json`, `report.json`, `availability.json`, `raw/` |
| `output/walmart-100-bentonville/latest/` | Last **published** (validated) dataset, from run `20261020T113321Z-48ec5f` (v1.0.0, 1,307 records). The failed full run did not replace it, by design. |
| `output/walmart-100-bentonville/state.json` | Location state. `open_run: null`; the re-check script sets it. |
| `tools-recheck/recheck_shortfall.py` | Re-queues **only** the listings that failed reconciliation. Not part of the scraper source, so the hash is unchanged. |
| `package-builders/` | `build_interim.py` and `write_index.py`, which build the client delivery zip from the checkpoint. Their paths are hard-coded to `D:\PROJECTS\Monthly-Test\...`; edit `ROOT`, `RUNDIR`, `EV` and `OUT` at the top. |

**Not included, on purpose:** the Oxylabs API key. Put it in `.env` yourself (step 2) and **never** put it in code, logs, zips or chat.

---

## 2. Run the re-check (about 40 minutes and ~1,200 Oxylabs requests)

Use Windows PowerShell; the macOS/Linux equivalents are in comments.

```powershell
# 1) unpack the source next to this file
Expand-Archive walmart-scraper-1.1.5-src.zip -DestinationPath .
cd walmart-scraper            # the folder inside the zip

# 2) Python 3.12+ and dependencies
python -m venv .venv; .\.venv\Scripts\Activate.ps1     # mac/linux: source .venv/bin/activate
pip install -r requirements.txt

# 3) provider key (Oxylabs Web API, the one with the credit)
"OXYLABS_WEBAPI_KEY=<paste key here>" | Out-File -Encoding ascii .env

# 4) put the run data where the scraper expects it
Copy-Item -Recurse ..\output .\output                 # mac/linux: cp -r ../output ./output

# 5) offline tests must pass (43 passed)
$env:PYTHONPATH="src"; python -m pytest -q             # mac/linux: PYTHONPATH=src python -m pytest -q

# 6) confirm the hash is still the delivered one
python -c "from wmscraper.version import version_info; print(version_info())"
#    must print 1.1.5 / 75d76e0e...  If not, the source was changed - stop.

# 7) see what will be re-checked (no requests)
python ..\tools-recheck\recheck_shortfall.py --scraper-dir . --run-id 20261024T043517Z-fa478c --dry-run
#    expected: "198 listings to re-check, ~1160 pages"

# 8) re-queue them and re-open the run
python ..\tools-recheck\recheck_shortfall.py --scraper-dir . --run-id 20261024T043517Z-fa478c

# 9) resume the SAME run (never add --fresh)
python -m wmscraper run --location walmart-100-bentonville --max-requests 3000 *> recheck-run.log
```

**Expected:** about 1,160 listing pages at ~35 per minute (Oxylabs takes 45–75 s per request; that is their latency, not your internet). Then validation runs.

**Read the result:**

```powershell
python -c "import json;r=json.load(open('output/walmart-100-bentonville/runs/20261024T043517Z-fa478c/report.json',encoding='utf-8'));v=r['validation'];print('OK' if v['ok'] else 'NOT OK', len(v['errors']), 'errors');print(*v['errors'][:15],sep='\n');print('published:', r.get('published'))"
```

* **OK / published:** `output/walmart-100-bentonville/latest/` now holds the validated 58k-product dataset. Rebuild the client package (section 5) and send the follow-up message (section 6A).
* **Still NOT OK:** compare the new `seen` figures with the earlier ones in `recheck-20261024T043517Z-fa478c.json`. If the same listings come out short by about the same amounts, the gap comes from Walmart (its count includes variants shown as one tile), not from missed pages. Report that per listing (section 6B). **Do not** change the validation thresholds to force publication.

**If it stops** (credit runs out, PC turns off, network drops): nothing is lost. Run step 9 again **without `--fresh`** and it resumes. `QUOTA_EXCEEDED` or HTTP 402 in the log means the Oxylabs credit is gone.

---

## 3. Rules that must not be broken

1. **Never** use `--fresh` on this location: it closes the open run and starts from zero (all credit wasted).
2. **Never** edit anything in `src/`, `config/`, `tools/`, `tests/`, `deploy/`, `requirements.txt` or `Dockerfile`. The source hash covers all of them, and the client wants evidence on **one exact hash**. If a code change is genuinely needed, bump `src/wmscraper/__init__.py` to the next version, rebuild with `python tools/package_source.py`, and disclose it.
3. **Never** loosen validation (`config/settings.yaml → validation`) to make a run publish.
4. Keep the API key only in `.env` and Azure Key Vault. Do not paste it into chat with another AI either.
5. Do not delete or rename `output/.../runs/20261024T043517Z-fa478c/`.
6. Do not edit `checkpoint.sqlite` by hand. If the scraper process was killed, do **not** delete `checkpoint.sqlite-journal`; SQLite needs it to roll back.

---

## 4. What happened in the session

**Client requirements** (from Darren's feedback, 20–24 Oct):
- Full uncapped traversal of store #100's assortment (11 CSV categories, all subcategories, all pages), with category/subcategory/page/source-count reconciliation.
- Prices, PPM and promotions bound to the selected store offer, with the store and fulfilment confirmed explicitly in the price-bearing responses.
- Retain unavailable store products, including carried identities with their old observation dates. Never present online or marketplace prices as local.
- Genuine UPCs, PPM scraped directly, the exact 22 fields, empty strings for missing values, blank gupc/unit_price, no approximate weights, complete volume/digital terms.
- Hard kill and resume; a deliberately failed run that leaves the last good output unchanged; an unattended Azure repeat. All on one exact hash.
- Offline tests labelled separately. Report requests and cost per phase, and flag any shortfall **before** spending more.
- Mariano's #60 stays separate (code only; no live collection yet).

**Problems found and fixed in v1.1.1 → v1.1.5:**
- **Ground Coffee loop:** an alias path to the Coffee node on which Walmart ignores the price filter. Now each node id is planned once, and an unfiltered price band is recorded as an "unresolved route".
- **The old expected total (Walmart's pickup-facet count) also counts marketplace and online-only items**, so it could never reconcile. Now listings are store-pinned (`stores=100`, Oxylabs `store_id=100`, ZIP 72712) and Walmart-sold only (`facet=retailer_type:Walmart`), with no availability filter. Every node is split until it fits the 25-page window, read to Walmart's last page, and reconciled against Walmart's own total (`crawl.coverage: source_count`).
- **Walmart quirks:** a count that isn't backed by served products (search-fallback counts), empty price bands, and off-by-one counts. These are reported as warnings (empty pages are re-fetched once); real shortfalls still fail.
- **Food root planned as one listing** (short first page). Fixed in 1.1.2: a node with subcategories is always split. The wrong rows were removed from the checkpoint, and this is recorded as a `planning_correction` event with both hashes.
- 1.1.3: concurrency settings. 1.1.4: clean product URLs at output. 1.1.5: the "UPC pending" marking done in one database transaction (it had taken ~85 minutes).

**Final live run `20261024T043517Z-fa478c`:**
- Started 04:35 UTC, hard-killed at 04:44:48 UTC and resumed; paging finished 12:47 UTC; run ended 13:56 UTC.
- 3,294 listings and 14,238 listing pages; all listings done; 0 capped.
- 14,665 price-bearing pages verified at `initialData.pageMetadata.location` storeId 100, with 0 mismatches. Canaries 10450114 and 43436773 were OK at the start and end.
- 58,198 distinct products: 37,219 available, 20,855 out of stock, 124 carried forward (`last_observed`, original date).
- 214,991 online-only and 2,432 marketplace listings excluded; 251 approximate-weight items excluded.
- 2,673 genuine UPCs (product pages with store confirmed, plus reuse from the v1.0.0 verified run); about 55k are queued for later runs (≤1,200 per run).
- PPM on 44,736 products; sale_price on 8,543. Volume/digital deals: none displayed (102 labels classified in the offer census).
- Reconciliation: 2,458 listings reconciled; 638 reported as warnings (empty at source, or a Walmart count not backed by products); **198 short** (median 86% seen, 7,726 products in total). All 198 stopped at Walmart's own last page. **Validation failed, so the run was not published.**
- About 17,000 requests in this run (collection 14,238; planning ~921; identity 1,615; failed runs 120; canaries 21).

**Deliberately failed run:** `20261024T133626Z-caf551` on v1.1.5, in a sandbox output holding a copy of the real `latest/`, starved to 40 requests. It was not published, and the checksums were identical before and after. Its files are in the delivery zip under `06-…`.

**Delivered to the client** (or ready to send): `D:\PROJECTS\Monthly-Test\walmart-contest-submission\wm-delivery-v1.1.5.zip` (13.8 MB), with `EVIDENCE-INDEX.md` first.

**Still open:**
- The 198-listing gap (this re-check).
- The remaining UPCs.
- The Azure repeat: a second full traversal (~17k requests), which needs the client to approve the credit.
- Mariano's #60.

**Azure** (already deployed earlier):
- Container Apps Job, cron `0 6 * * 1,4`. The job runs the release ZIP from Blob via managed identity, and the key is in Key Vault secret `oxylabs-webapi-key`.
- See `deploy/azure/deploy.sh` and `collect_evidence.sh` inside the source.
- The Azure blob still holds the **v1.1.0** release. Before an Azure repeat, upload `walmart-scraper-1.1.5-src.zip` with `deploy.sh` and update the job's `RELEASE_BLOB`. Only do this after the client approves the credit.

---

## 5. Rebuild the client package after the re-check

Edit the paths at the top of `package-builders/build_interim.py` and `write_index.py`, then:

```powershell
python ..\package-builders\build_interim.py
python ..\package-builders\write_index.py
```

This creates `wm-delivery-v1.1.5\` and `wm-delivery-v1.1.5.zip`. If the run published, update the "Result" line and the "Outstanding" table in `write_index.py` before running it (say *published*, and remove the 198-listing item). Then search the zip for the key; there must be no hit.

---

## 6. Follow-up message to the client

**A. If the re-check published:**

```
Hello Darren,
Follow-up to my final package: the 198 listings that were short of Walmart's count were re-checked on the same run and the same hash (1.1.5, 75d76e0e…). The run now passes validation and is published. The updated package is attached; EVIDENCE-INDEX.md shows the reconciliation for all 3,294 listings. Requests used for the re-check: <N>.
Remaining: UPCs for the queued products (up to 1,200 per scheduled run) and the unattended Azure repeat, which needs your approval for credit (about 17,000 requests).
Best regards,
Asif Khan
```

**B. If it is still short:**

```
Hello Darren,
Follow-up to my final package: I re-read the 198 short listings from page 1 on the same run and hash (1.1.5). <X> now reconcile; <Y> remain short by the same amounts, while every page Walmart serves for them is read to its last page. The remaining gap therefore comes from Walmart's reported totals (variants grouped into one tile on the listing), not from missed pages. The per-listing figures are in recheck-20261024T043517Z-fa478c.json and the reconciliation CSV. Publication stays blocked until you confirm how these listings should be treated; I have not loosened validation. Requests used: <N>.
Best regards,
Asif Khan
```

---

## 7. Useful commands

```powershell
# progress while running (read-only, safe)
python -c "import sqlite3;c=sqlite3.connect('file:output/walmart-100-bentonville/runs/20261024T043517Z-fa478c/checkpoint.sqlite?mode=ro',uri=True,timeout=20);print(c.execute('select status,count(*) from listings group by status').fetchall(), c.execute('select count(*) from items').fetchone())"

# key check (expect 400 = key valid; 401 = invalid key)
python -c "import os,httpx;from dotenv import load_dotenv;load_dotenv();print(httpx.post('https://webapi.oxylabs.io/v1/scrape/walmart',headers={'Authorization':'Bearer '+os.environ['OXYLABS_WEBAPI_KEY']},json={'url':'https://www.walmart.com/store/100','store_id':100},timeout=60).status_code)"
```

Note: the scraper itself reads `.env` when started with `python -m wmscraper`. Helper scripts that import it directly need the key loaded into the environment first.
