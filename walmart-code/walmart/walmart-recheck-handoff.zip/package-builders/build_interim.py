"""Builds the interim reviewable package from the LIVE checkpoint (read-only) + existing evidence files."""
import csv, gzip, hashlib, json, shutil, sqlite3, sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(r"D:\PROJECTS\Monthly-Test\walmart-scraper")
sys.path.insert(0, str(ROOT / "src"))
from wmscraper.models import FIELD_ORDER
from wmscraper.parse import deals
from wmscraper.parse.walmart import parse_listing, product_url
from wmscraper.version import version_info

RUN = "20261024T043517Z-fa478c"
RUNDIR = ROOT / "output/walmart-100-bentonville/runs" / RUN
EV = ROOT / "evidence/20261024T043331Z"
OUT = Path(r"D:\PROJECTS\Monthly-Test\walmart-contest-submission\wm-delivery-v1.1.5")
if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)
now = datetime.now(timezone.utc).isoformat(timespec="seconds")
v = version_info()

c = sqlite3.connect(f"file:{RUNDIR / 'checkpoint.sqlite'}?mode=ro", uri=True, timeout=5)
rows_e = c.execute("SELECT record, enriched, item_id FROM items ORDER BY rowid").fetchall()
records = [json.loads(r[0]) for r in rows_e]
ident = {json.loads(r[0])["url"].split("?")[0]: r[1] for r in rows_e}
for r in records:
    r["url"] = product_url(r["url"])  # same output-boundary cleaning as Checkpoint.records()
avail = {r[0]: dict(zip(("item_id", "status", "source_value", "price_source", "observed_at", "url"), (*r[:5], product_url(r[5]))))
         for r in c.execute("SELECT item_id, status, source_value, price_source, observed_at, url FROM availability")}
cur = c.execute("SELECT category, sub_category, url, status, next_page, max_page, reported_total, page_size, seen, kept, "
                "store_available, store_oos, stop_reason, error FROM listings ORDER BY rowid")
cols = [d[0] for d in cur.description]
listings = [dict(zip(cols, r)) for r in cur.fetchall()]
reasons = dict(c.execute("SELECT reason, COUNT(*) FROM seen GROUP BY reason").fetchall())
events = [(t, k, json.loads(d)) for t, k, d in c.execute("SELECT ts, kind, detail FROM events ORDER BY rowid")]
meta = {k: json.loads(val) for k, val in c.execute("SELECT k, v FROM meta WHERE k NOT LIKE 'plan:%'")}
plans = c.execute("SELECT COUNT(*) FROM meta WHERE k LIKE 'plan:%'").fetchone()[0]

# 1. source
d = OUT / "01-source"; d.mkdir()
z = ROOT / "dist" / f"walmart-scraper-{v['version']}-src.zip"
shutil.copy(z, d / z.name)
(d / "SOURCE-HASH.txt").write_text(
    f"version {v['version']}\nsource_sha256 {v['source_sha256']}\nzip_sha256 {hashlib.sha256(z.read_bytes()).hexdigest()}\n"
    "source_sha256 = fingerprint over src, config, deploy, tools, tests, requirements, Dockerfile (tools/package_source.py)\n",
    encoding="utf-8")

# 2. dataset snapshot (every record is a fresh store-#100 offer from a verified store-pinned listing)
d = OUT / "02-live-dataset-snapshot"; d.mkdir()
assert all(tuple(r) == FIELD_ORDER for r in records)
(d / "walmart-store100-live-snapshot.json").write_text(json.dumps(records, indent=1, ensure_ascii=False), encoding="utf-8")
by_cat = {}
for r in records:
    by_cat.setdefault(r["category"], []).append(r)
def _rank(r):  # verified identity first, then out-of-stock store items (retention), then the rest
    a = avail.get(r["url"].rstrip("/").split("/")[-1], {})
    return (0 if r["upc"] else 1, 0 if a.get("status") == "out_of_stock" else 1)
demo = [r for cat in sorted(by_cat) for r in sorted(by_cat[cat], key=_rank)[:46]][:500]
if len(demo) < 500:
    ids = {id(r) for r in demo}
    demo += [r for r in records if id(r) not in ids][:500 - len(demo)]
(d / "walmart-store100-demo-500.json").write_text(json.dumps(demo, indent=1, ensure_ascii=False), encoding="utf-8")
av_rows = list(avail.values())
(d / "availability.json").write_text(json.dumps(av_rows, indent=1, ensure_ascii=False), encoding="utf-8")
n = len(records) or 1
fill = {f: sum(1 for r in records if r[f]) for f in FIELD_ORDER}
status_c = Counter(a["status"] for a in av_rows)
deal_v = sum(1 for r in records if r["volume_deals_description"])
deal_d = sum(1 for r in records if r["digital_deals_description"])
census = meta.get("offer_census", {})
census_rows = []
for text, e in sorted(census.items(), key=lambda kv: -kv[1]["count"]):
    k = deals.classify([text])
    kind = ("volume_deal" if k.volume_description else "digital_deal" if k.digital_description
            else "reward_not_a_price_reduction" if k.ignored_rewards else "other_label")
    census_rows.append({"label": text, "classified_as": kind, **e})
(d / "offer-census.json").write_text(json.dumps(census_rows, indent=1, ensure_ascii=False), encoding="utf-8")
stats = {"run_id": RUN, "snapshot_taken_at": now, "status": "IN-PROGRESS snapshot (not a published dataset; run not finished)",
         "records": len(records), "distinct_urls": len({r["url"] for r in records}),
         "records_by_category": {k: len(x) for k, x in sorted(by_cat.items())},
         "availability_status": dict(status_c),
         "field_fill_counts": fill,
         "gupc_unit_price_all_empty": all(r["gupc"] == "" and r["unit_price"] == "" for r in records),
         "upc_identity": {"upc_from_product_page_this_run_store_confirmed": sum(1 for r in records if r["upc"] and ident.get(r["url"]) == 1),
                          "upc_reused_from_last_published_verified_run": sum(1 for r in records if r["upc"] and ident.get(r["url"]) == 5),
                          "product_page_fetched_but_no_upc_displayed": sum(1 for r in records if not r["upc"] and ident.get(r["url"]) == 1),
                          "identity_not_yet_fetched": sum(1 for r in records if ident.get(r["url"]) == 0)},
         "volume_deal_records": deal_v, "digital_deal_records": deal_d,
         "offer_labels_displayed_by_class": dict(Counter(x["classified_as"] for x in census_rows)),
         "excluded_or_not_store_assortment": {k: x for k, x in reasons.items() if k not in ("kept", "duplicate")},
         "duplicates_prevented": reasons.get("duplicate", 0)}
(d / "dataset-stats.json").write_text(json.dumps(stats, indent=1, ensure_ascii=False), encoding="utf-8")

# 3. reconciliation
d = OUT / "03-reconciliation"; d.mkdir()
win = 25
def verdict(l):
    if l["status"] == "failed":
        return "FAILED: " + l["error"]
    if l["status"] != "done":
        return "IN PROGRESS"
    if not l["reported_total"]:
        return "empty at source (Walmart reports 0)"
    if not l["page_size"]:
        return "Walmart count not backed by products (0 served, re-fetched)"
    reach = min(l["reported_total"], win * l["page_size"])
    if l["seen"] >= 0.95 * reach or reach - l["seen"] <= 2:
        return "RECONCILED"
    if l["stop_reason"] == "walmart_served_no_more_products" or l["page_size"] < 20:
        return "Walmart count not backed by products (served until it stopped)"
    return "SHORTFALL"
with (d / "listing-reconciliation.csv").open("w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh)
    w.writerow(["category", "sub_category", "listing_url (store-pinned, Walmart-sold)", "status", "pages_read",
                "walmart_max_page", "walmart_reported_total", "products_seen", "new_distinct_kept", "store_offers_available",
                "store_offers_out_of_stock", "online_only_or_other (seen - store)", "stop_reason", "verdict"])
    for l in listings:
        w.writerow([l["category"], l["sub_category"], l["url"], l["status"], l["next_page"] - 1, l["max_page"],
                    l["reported_total"], l["seen"], l["kept"], l["store_available"], l["store_oos"],
                    max(0, l["seen"] - l["store_available"] - l["store_oos"]), l["stop_reason"], verdict(l)])
cat_rows = {}
for l in listings:
    x = cat_rows.setdefault(l["category"], Counter())
    x["listings"] += 1; x["pages_read"] += l["next_page"] - 1; x["walmart_reported"] += l["reported_total"] or 0
    x["seen"] += l["seen"]; x["store_available"] += l["store_available"]; x["store_oos"] += l["store_oos"]
    x[verdict(l).split(":")[0].split(" (")[0]] += 1
with (d / "category-summary.csv").open("w", newline="", encoding="utf-8") as fh:
    keys = ["listings", "pages_read", "walmart_reported", "seen", "store_available", "store_oos", "RECONCILED", "IN PROGRESS",
            "FAILED", "SHORTFALL", "empty at source", "Walmart count not backed by products"]
    w = csv.writer(fh); w.writerow(["category"] + keys + ["distinct_records_kept"])
    for cat, x in sorted(cat_rows.items()):
        w.writerow([cat] + [x.get(k, 0) for k in keys] + [len(by_cat.get(cat, []))])
vc = Counter(verdict(l).split(":")[0] for l in listings)

# 4. raw source responses + source-to-output examples
d = OUT / "04-raw-source-responses"; shutil.copytree(RUNDIR / "raw", d)
recs = {r["url"]: r for r in records}
ex = []
for f in sorted((RUNDIR / "raw").glob("listing-*.html.gz")):
    html = gzip.decompress(f.read_bytes()).decode("utf-8", "ignore")
    lp = parse_listing(html, "")
    for it in lp.items:
        r = recs.get(it.url)
        if r and len(ex) < 12 and (r["ppm"] or r["sale_price"] or it.availability("100") == "out_of_stock" or len(ex) < 4):
            ex.append({"raw_file": f.name, "selected_location_on_page": lp.location,
                       "source": {"item_id": it.item_id, "title": it.title, "fulfillmentType": it.fulfillment_type,
                                  "fulfillment_store_ids": sorted(it.store_ids_any), "availability": it.availability_value,
                                  "current_price": it.current_price, "was_price": it.was_price, "unit_price_displayed": it.ppm,
                                  "promo_labels": it.promo_texts, "marketplace": it.is_marketplace},
                       "output_record": r})
(OUT / "04-source-to-output-examples.json").write_text(json.dumps(ex, indent=1, ensure_ascii=False), encoding="utf-8")

# 5. kill/resume
d = OUT / "05-hard-kill-and-resume"; d.mkdir()
for name in ("02-run-part1-hard-killed.log", "03-run-resumed.log", "04-run-resumed-after-planning-correction.log",
             "05-run-resumed-v1.1.3-concurrency.log", "06-run-resumed-v1.1.4-clean-urls.log",
             "07-identity-step-upc-sample.log", "08-run-resumed-after-identity-sample.log", "09-run-resumed-v1.1.5-final.log",
             "01-store-verification.log"):
    if (EV / "B-live-walmart" / name).exists():
        shutil.copy(EV / "B-live-walmart" / name, d / name)
sessions = [{"ts": t, **{k: x.get(k) for k in ("version", "source_sha256", "resumed", "items_already_kept")}}
            for t, k, x in events if k == "session_start"]
(d / "resume-proof.json").write_text(json.dumps({
    "run_id": RUN, "hard_kill": "process killed without cleanup at 2026-10-24T04:44:48Z after 301 committed pages, 4129 items saved",
    "resumed_same_run_id": True, "sessions": sessions,
    "run_resumed_events": [{"ts": t, **x} for t, k, x in events if k == "run_resumed"][:5]}, indent=1), encoding="utf-8")
(OUT / "05-planning-correction-event.json").write_text(json.dumps(
    [{"ts": t, **x} for t, k, x in events if k == "planning_correction"], indent=1), encoding="utf-8")

# 6. failed run
d = OUT / "06-deliberately-failed-run"; d.mkdir()
D = EV / "D-live-failed-run-not-published"
for name in ("01-latest-checksums-BEFORE.txt", "02-failed-run.log", "03-latest-checksums-AFTER.txt", "04-failed-run-report.json"):
    shutil.copy(D / name, d / name)
fr = json.loads((D / "04-failed-run-report.json").read_text(encoding="utf-8"))
same = (D / "01-latest-checksums-BEFORE.txt").read_text() == (D / "03-latest-checksums-AFTER.txt").read_text()

# 7. offline tests (separate)
d = OUT / "07-OFFLINE-automated-tests"; d.mkdir()
shutil.copy(EV / "A-unit-and-simulated" / "test-results-v1.1.5.txt", d / "test-results-v1.1.5.txt")
(d / "README.txt").write_text("OFFLINE automated tests on synthetic fixture pages (NOT Walmart data, NOT live results).\n", encoding="utf-8")

done = [l for l in listings if l["status"] == "done"]
running = [l for l in listings if l["status"] != "done"]
remaining_pages = sum(max(0, min(l["max_page"] or 25, 25) - (l["next_page"] - 1)) for l in running)
summary = {"generated_at": now, "version": v, "run_id": RUN, "records": len(records), "listings": len(listings),
           "listings_done": len(done), "listings_open": len(running), "verdicts": dict(vc),
           "pages_read": sum(l["next_page"] - 1 for l in listings), "planning_nodes_checkpointed": plans,
           "remaining_pages_upper_bound": remaining_pages, "food_planning_complete": meta.get("discovered:Food"),
           "store_verified_pages": meta.get("store_verified_pages"), "store_mismatches": meta.get("store_mismatches", 0),
           "failed_run": {"run_id": fr["run_id"], "validation_ok": fr["validation"]["ok"], "published": fr.get("published"),
                          "latest_checksums_identical": same, "source_sha256": fr["scraper"]["source_sha256"]},
           "stats": stats}
(OUT / "summary.json").write_text(json.dumps(summary, indent=1, ensure_ascii=False), encoding="utf-8")
print(json.dumps({k: summary[k] for k in summary if k != "stats"}, indent=1))
print(json.dumps({k: stats[k] for k in ("records_by_category", "availability_status", "volume_deal_records",
                                         "digital_deal_records", "offer_labels_displayed_by_class",
                                         "excluded_or_not_store_assortment")}, indent=1))
print({f: fill[f] for f in ("upc", "ppm", "regular_price", "sale_price", "weight", "image_url")}, "examples", len(ex))
