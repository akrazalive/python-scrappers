# Walmart #32/#38 – store #100 evidence index

**Source:** walmart-scraper **1.1.5** · source_sha256 `75d76e0ee62a06e8bfaf48b245852463f08528537099f35a99fbfffcc3e343cc` (`01-source/`; run instructions in README.md / docs/OPERATIONS.md inside the ZIP)
**Store:** #100 Bentonville S Walton Blvd Supercenter, 406 S Walton Blvd, Bentonville, AR 72712 · ZIP 72712
**Full live run:** `20261024T043517Z-fa478c` · started 2026-10-24 04:35 UTC · traversal finished 12:47 UTC · run ended 13:56 UTC
**Result:** full uncapped traversal **completed** (every planned listing paginated to Walmart's last page); validation **blocked publication** on a source-count gap in 198 of 3,294 listings (below) – the dataset is therefore delivered as the run's output, **not** as a published "latest".

Live observed results and offline tests are kept separate. Nothing under "OFFLINE" is retailer data.

## Completed – live, observed

| Requirement | Result | Evidence |
|---|---|---|
| Correct store before collection | store #100 name, address, ZIP verified; canary items 10450114 / 43436773 readable for store #100 at start **and** end | `05-hard-kill-and-resume/01-store-verification.log`, `08-final-run-validation/run-report.json → canary` |
| Selected store / fulfillment on price-bearing pages | **14,665** listing pages verified at `initialData.pageMetadata.location` = storeId 100, intent PICKUP, ZIP 72712; **0 mismatches** | `04-raw-source-responses/index.json`, `04-source-to-output-examples.json` |
| All categories, subcategories, pagination – no demo caps | 11 categories · **3,294 listings** (subcategories, then whole-dollar price bands where a node exceeds 25 pages) · **14,238 listing pages**, each listing read to Walmart's last page · 0 capped listings | `03-reconciliation/listing-reconciliation.csv`, `category-summary.csv` |
| Source-count reconciliation | **2,458 listings reconciled** with Walmart's own total · 38 empty at source · 600 where Walmart's total is not backed by served products (pages served until Walmart stopped; empty pages re-fetched) · **198 short – see Outstanding** | same CSV, column `verdict` |
| Genuine distinct products (≥ 500) | **58,198** distinct store-#100 products in the exact 22-field order; `walmart-store100-demo-500.json` = 500 across all categories | `02-live-dataset-snapshot/` |
| Unavailable store products retained | **20,855 out-of-stock** store products kept; 37,219 available; **124 previously published products not returned this run carried forward with their original observation date** (`price_source: last_observed`) | `02-live-dataset-snapshot/availability.json` |
| Online / marketplace never stand in for store prices | 214,991 online-only (FC) and 2,432 marketplace listings seen and excluded | `dataset-stats.json` |
| Approximate-weight exclusion | 251 excluded | same |
| Genuine UPCs (never inferred) | **2,673** from product pages with store #100 confirmed (`location.pickupLocation.storeId`) in this run (1,555) or verified the same way in the last published run; 60 product pages show no UPC (left empty). Walmart listings carry no UPC: the other ~55,465 are queued for product pages on following runs (≤1,200 per run) | `dataset-stats.json → upc_identity`, `04-raw-source-responses/product-*.html.gz` |
| Prices, PPM, promotions from the store offer only | regular_price 58,188 (100.0%) · sale_price (Rollback/was) 8,543 (14.7%) · PPM exactly as displayed 44,736 (76.9%) (empty = no unit price displayed) · blank gupc/unit_price: True | `04-source-to-output-examples.json` |
| Volume / digital deals with full terms | **none displayed** on these store offers: all 102 distinct labels shown are listed and classified (Rollback, "Save with", SNAP EBT, pickup/delivery times …); no "N for $X", coupon or clip label occurred, so these fields are correctly empty | `02-live-dataset-snapshot/offer-census.json` |
| Hard kill and resume | killed without cleanup 04:44:48 UTC after 301 committed pages / 4,129 products; resumed under the same run id, no loss or duplicates; every later session also resumed from the checkpoint | `05-hard-kill-and-resume/` |
| Deliberately failed run keeps last good output | live run `20261024T133626Z-caf551` on store #100 with **this** source (75d76e0ee62a…), starved to 40 requests → failed validation, **not published**; last good `records/manifest/report.json` checksums identical before/after | `06-deliberately-failed-run/` |
| Failed full run does not replace last good output | the full run itself failed validation → `latest/` untouched (still run 20261020T113321Z-48ec5f) | `08-final-run-validation/validation-result.json` |
| Disclosed corrections during the run | Food root first planned as one listing (fixed 1.1.2, rows removed, Food re-planned); one listing re-queued after a page without results; every session's exact hash recorded | `05-planning-correction-event.json`, `05-hard-kill-and-resume/resume-proof.json` |

## Outstanding

| Item | State / blocker | Next step |
|---|---|---|
| Source-count gap, 198 listings (6%) | all 198 were read to **Walmart's own last page**, yet Walmart's count is higher (median 86% seen; 7,726 products in total). Most likely Walmart counting variants it groups into one tile, or count drift during the crawl – not yet proven, so validation correctly blocks publication | re-crawl only these 198 listings (~1,200 pages) and compare against the variant counts on the page; then either publish or report the cause per listing |
| Published validated dataset | blocked by the item above | as above |
| Remaining UPCs | ~55,465 queued (≤1,200 product pages per scheduled run) | following runs, or one larger identity pass if funded |
| Unattended Azure repeat | not run for this version | second full traversal ≈ 17k requests – needs credit approval |

## What the $25 Oxylabs credit covered (this run)

Reconstructed from the checkpoint (1 request = 1 Walmart page via Oxylabs; the provider dashboard is authoritative for cost):

| Phase | Requests |
|---|---|
| Collection – listing pages to Walmart's last page | 14,238 |
| Planning – split nodes + price-band probes | 921 |
| Empty-page re-fetches (confirming source behaviour) | 88 |
| Identity – product pages for UPC | 1,615 |
| Store verification + canaries | 21 |
| Recovery (hard kill + resumes) | 0 extra (resumed from checkpoint) |
| Failed-run protection (3 live starved runs) | 120 |
| **Total for this run** | **≈ 17,003** |

Earlier attempts on the same key (22 Oct run, stopped attempts today) used further credit; those are kept for audit only and are not part of these results.

## OFFLINE – automated tests (not live results)

`07-OFFLINE-automated-tests/test-results-v1.1.5.txt`: 43 tests on synthetic fixture pages.
