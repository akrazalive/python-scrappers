"""Version ledger for run 20261024T043517Z-fa478c: re-computes each delivered source zip's fingerprint (same algorithm
as wmscraper/version.py), matches it to the session hashes in the run checkpoint, and lists file changes between versions."""
import difflib, hashlib, json, sqlite3, sys, zipfile
from pathlib import Path

ROOT = Path(r"E:\scrappers\walmart-code\walmart-scraper")
RUN = "20261024T043517Z-fa478c"
OUT = Path(sys.argv[1])
INCLUDE = ("src/", "config/", "deploy/", "tools/", "tests/")
INCLUDE_FILES = ("requirements.txt", "Dockerfile")
EXCLUDE_PARTS = {"__pycache__", ".pytest_cache", "output", "evidence", "dist", "entry"}


def members(z):
    out = {}
    for n in z.namelist():
        if n.endswith("/"):
            continue
        rel = n.split("/", 1)[1] if n.startswith("walmart-scraper/") else n
        parts = set(rel.split("/"))
        if not (rel.startswith(INCLUDE) or rel in INCLUDE_FILES) or EXCLUDE_PARTS & parts:
            continue
        if rel.endswith((".pyc", ".sqlite")) or rel.endswith("/.env") or rel == ".env":
            continue
        out[rel] = z.read(n).replace(b"\r\n", b"\n")
    return out


def fp(files):
    h = hashlib.sha256()
    for rel in sorted(files):
        h.update(rel.encode()); h.update(b"\0"); h.update(files[rel]); h.update(b"\0")
    return h.hexdigest()


c = sqlite3.connect(f"file:{ROOT / 'output/walmart-100-bentonville/runs' / RUN / 'checkpoint.sqlite'}?mode=ro", uri=True)
sessions = [{"started_utc": ts, **{k: json.loads(d).get(k) for k in ("version", "source_sha256", "resumed", "items_already_kept")}}
            for ts, d in c.execute("SELECT ts, detail FROM events WHERE kind='session_start' ORDER BY rowid")]
versions, prev = [], None
for ver in ("1.1.1", "1.1.2", "1.1.3", "1.1.4", "1.1.5"):
    zp = ROOT / "dist" / f"walmart-scraper-{ver}-src.zip"
    if ver == "1.1.1":  # dist/ copy was rebuilt after the run started; the original is in the run's evidence folder
        zp = ROOT / "evidence/20261024T043331Z/0-source" / zp.name
    files = members(zipfile.ZipFile(zp))
    f = fp(files)
    run_hashes = {s["source_sha256"] for s in sessions if s["version"] == ver}
    changes = []
    if prev:
        for rel in sorted(set(files) | set(prev)):
            a, b = prev.get(rel), files.get(rel)
            if a == b:
                continue
            if a is None or b is None:
                changes.append({"file": rel, "change": "added" if a is None else "removed"}); continue
            dl = list(difflib.unified_diff(a.decode("utf-8", "ignore").splitlines(), b.decode("utf-8", "ignore").splitlines(), lineterm="", n=0))
            changes.append({"file": rel, "lines_added": sum(1 for l in dl if l.startswith("+") and not l.startswith("+++")),
                            "lines_removed": sum(1 for l in dl if l.startswith("-") and not l.startswith("---"))})
            (OUT / f"diff-{versions[-1]['version']}-to-{ver}.patch").open("a", encoding="utf-8").write(
                "\n".join(difflib.unified_diff(a.decode("utf-8", "ignore").splitlines(), b.decode("utf-8", "ignore").splitlines(),
                                               f"{versions[-1]['version']}/{rel}", f"{ver}/{rel}", lineterm="")) + "\n")
    versions.append({"version": ver, "zip": zp.name, "zip_sha256": hashlib.sha256(zp.read_bytes()).hexdigest(),
                     "fingerprint_recomputed_from_zip": f, "fingerprint_recorded_in_run": sorted(run_hashes),
                     "matches": run_hashes == {f}, "files_changed_from_previous": changes})
    prev = files
json.dump({"run_id": RUN, "sessions": sessions, "versions": versions}, open(OUT / "version-ledger.json", "w"), indent=1)
for v in versions:
    print(v["version"], v["fingerprint_recomputed_from_zip"][:12], "matches run:", v["matches"],
          [(x["file"], x.get("lines_added"), x.get("lines_removed"), x.get("change")) for x in v["files_changed_from_previous"]])
