"""Raw-page evidence for the listings that remain short of Walmart's reported total after the re-check.

For each short listing (verdict SHORTFALL in recheck-before-after.csv) it fetches Walmart's pages through the scraper's
own store-pinned fetcher (store 100, ZIP 72712, Walmart-sold facet), archives every raw response, and measures what the
page itself shows: Walmart's total (aggregatedCount) per page, maxPage, product tiles per page, non-product tiles,
pinned tiles, duplicate tiles inside the listing, and the variant item ids Walmart folds into one tile
(variantCriteria[].variantList[].selectedProduct.usItemId). Each folded variant id is then looked up in the run's own
checkpoint: kept in the dataset from another listing, seen and excluded (online-only / marketplace / approximate
weight), or not seen anywhere in the run.

Modes (no request is made unless --fetch is given):
  --plan                       selection and the exact number of requests the fetch would need
  --offline DIR                analyse already archived raw listing pages (*.html.gz) - used to test the parser
  --fetch --max-requests N     fetch; N is a hard cap on provider requests INCLUDING retries (the run stops at N)

  --variant-check N --raw-dir D [--raw-dir D2] --fetch --max-requests M
                               product pages for N folded variant ids (from archived listing pages) that the run never
                               saw as a tile: is each one a store-100 offer (in scope) or online-only / marketplace?
  --offline-products DIR       classify already archived product pages (*.html.gz) - parser test

  --pages all                  every page of each listing (needed to count folded variants per listing)
  --pages first-last           page 1 and Walmart's last page only

This file is NOT part of the scraper source (source hash unchanged). It never writes to the run checkpoint.
"""
from __future__ import annotations

import argparse
import asyncio
import csv
import gzip
import json
import sqlite3
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("--scraper-dir", required=True)
ap.add_argument("--run-id", default="20261024T043517Z-fa478c")
ap.add_argument("--location", default="walmart-100-bentonville")
ap.add_argument("--csv", required=True, help="09-shortfall-recheck/recheck-before-after.csv")
ap.add_argument("--out", required=True)
ap.add_argument("--pages", choices=("all", "first-last"), default="all")
ap.add_argument("--plan", action="store_true")
ap.add_argument("--offline")
ap.add_argument("--fetch", action="store_true")
ap.add_argument("--max-requests", type=int, default=0)
ap.add_argument("--tolerance", type=int, default=2)
ap.add_argument("--variant-check", type=int, default=0)
ap.add_argument("--raw-dir", action="append", default=[])
ap.add_argument("--offline-products")
a = ap.parse_args()

ROOT = Path(a.scraper_dir).resolve()
sys.path.insert(0, str(ROOT / "src"))
from wmscraper.parse.walmart import WALMART_SELLER_IDS, dig, next_data, page_location, parse_product  # noqa: E402

OUT = Path(a.out)
OUT.mkdir(parents=True, exist_ok=True)
rows = [r for r in csv.DictReader(open(a.csv, encoding="utf-8")) if r["verdict_after_recheck"] == "SHORTFALL"]


def wanted_pages(r) -> list[int]:
    last = int(r["walmart_last_page"]) or 1
    return list(range(1, last + 1)) if a.pages == "all" else sorted({1, last})


def analyse_page(html: str, final_url: str = "") -> dict:
    data = next_data(html, final_url)
    initial = dig(data, "props", "pageProps", "initialData") or {}
    sr = initial.get("searchResult") or dig(initial, "contentLayout", "searchResult") or {}
    pag = sr.get("paginationV2") or {}
    props = pag.get("pageProperties") or {}
    tiles, other, variants = [], Counter(), {}
    for stack in sr.get("itemStacks") or []:
        for it in stack.get("items") or []:
            t = it.get("__typename", "Product")
            if t != "Product":
                other[t] += 1
                continue
            iid = str(it.get("usItemId") or "")
            tiles.append(iid)
            vids = {str(dig(v, "selectedProduct", "usItemId") or "") for vc in it.get("variantCriteria") or []
                    for v in vc.get("variantList") or [] if isinstance(v, dict)}
            variants[iid] = sorted(x for x in vids if x and x != iid)
    pinned = [k for k, v in (props.get("itemStacks") or {}).items() if isinstance(v, dict) and v.get("pinnedTo")]
    return {"page": int(props.get("page") or 1), "walmart_total": int(sr.get("aggregatedCount") or 0),
            "max_page": int(pag.get("maxPage") or 0),
            "max_page_within_rerank": dig(props, "pap", "polaris", "ms_max_page_within_rerank"),
            "product_tiles": len(tiles), "non_product_tiles": dict(other), "pinned_tiles": len(pinned),
            "tile_ids": tiles, "folded_variants": variants, "location": page_location(data)}


def summarise(r, pages: list[dict], ck) -> dict:
    tiles = [i for p in pages for i in p["tile_ids"]]
    served = set(tiles)
    folded = {v for p in pages for vs in p["folded_variants"].values() for v in vs} - served
    kept = {i for i in folded if ck.execute("SELECT 1 FROM items WHERE item_id=?", (i,)).fetchone()}
    excluded = Counter()
    for i in folded - kept:
        row = ck.execute("SELECT reason FROM seen WHERE item_id=? AND reason NOT IN ('kept','duplicate') LIMIT 1", (i,)).fetchone()
        excluded[row[0] if row else "not_seen_anywhere_in_run"] += 1
    totals = sorted({p["walmart_total"] for p in pages})
    total = pages[0]["walmart_total"] if pages and pages[0]["page"] == 1 else int(r["walmart_total_recheck"])
    complete = a.pages == "all" and len(pages) == len(wanted_pages(r))
    gap = total - len(served)
    if not complete:
        verdict = "partial evidence (first/last page only)"
    elif gap <= a.tolerance:
        verdict = "reconciles on this read"
    elif gap - a.tolerance <= len(kept):
        verdict = "EXPLAINED: gap covered by folded variants already in the dataset as store-100 products"
    elif len(served) + len(folded) >= total - a.tolerance:
        verdict = "PARTLY EXPLAINED: needs folded variants that are not in the dataset"
    else:
        verdict = "UNEXPLAINED: gap exceeds all folded variants"
    return {"category": r["category"], "sub_category": r["sub_category"], "listing_url": r["listing_url"],
            "walmart_total_first_read": r["walmart_total_first_read"], "walmart_total_recheck": r["walmart_total_recheck"],
            "walmart_total_this_read": total, "walmart_totals_seen_across_pages": totals,
            "walmart_last_page": pages[-1]["max_page"] if pages else "", "pages_read": len(pages),
            "max_page_within_rerank": pages[0]["max_page_within_rerank"] if pages else "",
            "product_tiles": len(tiles), "distinct_products_served": len(served),
            "duplicate_tiles_in_listing": len(tiles) - len(served),
            "non_product_tiles": sum(sum(p["non_product_tiles"].values()) for p in pages),
            "tiles_per_page": [p["product_tiles"] for p in pages],
            "folded_variant_ids_not_served_as_tiles": len(folded),
            "folded_variants_kept_from_other_listings": len(kept),
            "folded_variants_excluded": dict(excluded),
            "gap_vs_walmart_total": gap,
            "gap_unexplained_after_folded_variants": max(0, total - len(served) - len(folded)),
            "store_context_ok": all(p["location"].get("storeId") == "100" for p in pages),
            "verdict": verdict}


def classify_product(html: str, final_url: str, item_id: str) -> dict:
    p = parse_product(html, final_url)
    walmart_sold = (p.seller_id or "").upper() in WALMART_SELLER_IDS or (p.seller_name or "").lower() in ("walmart.com", "walmart")
    ctx = (p.location or {}).get("pickupStoreId") == "100" or "100" in ((p.location or {}).get("storeIds") or [])
    if p.item_id != item_id:
        verdict = "page_served_another_item"
    elif not walmart_sold:
        verdict = "marketplace_not_in_scope"
    elif p.fulfillment_type.upper() == "STORE" and ctx:
        verdict = "STORE_100_OFFER_in_scope"
    elif p.fulfillment_type.upper() == "STORE":
        verdict = "store_offer_context_unconfirmed"
    else:
        verdict = "online_only_not_in_scope"
    return {"item_id": item_id, "response_item_id": p.item_id, "name": p.name, "fulfillment_type": p.fulfillment_type,
            "seller": p.seller_name, "pickup_store": (p.location or {}).get("pickupStoreId"), "price": p.current_price,
            "upc": p.upc, "verdict": verdict}


def folded_not_seen(ck, dirs) -> list[tuple[str, str]]:
    ids = {}
    for d in dirs:
        for f in sorted(Path(d).glob("*.html.gz")):
            if "product" in f.name or "store" in f.name or "category" in f.name:
                continue
            try:
                pg = analyse_page(gzip.decompress(f.read_bytes()).decode("utf-8", "ignore"))
            except Exception:
                continue
            for tile, vs in pg["folded_variants"].items():
                for v in vs:
                    ids.setdefault(v, f"{f.name}:{tile}")
    out = []
    for v, src in sorted(ids.items()):
        if ck.execute("SELECT 1 FROM items WHERE item_id=?", (v,)).fetchone() or            ck.execute("SELECT 1 FROM seen WHERE item_id=?", (v,)).fetchone():
            continue
        out.append((v, src))
    return out


def write(results: list[dict], meta: dict):
    (OUT / "shortfall-evidence.json").write_text(json.dumps({**meta, "listings": results}, indent=1, ensure_ascii=False),
                                                 encoding="utf-8")
    if results:
        with (OUT / "shortfall-evidence.csv").open("w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=list(results[0]))
            w.writeheader()
            w.writerows({k: json.dumps(v) if isinstance(v, (list, dict)) else v for k, v in x.items()} for x in results)
    print(json.dumps({**meta, "verdicts": dict(Counter(x["verdict"] for x in results))}, indent=1))


need = sum(len(wanted_pages(r)) for r in rows)
print(f"{len(rows)} short listings, --pages {a.pages}: {need} pages = {need} requests without retries")
if a.plan:
    raise SystemExit(0)

ck = sqlite3.connect(f"file:{ROOT / 'output' / a.location / 'runs' / a.run_id / 'checkpoint.sqlite'}?mode=ro", uri=True)

if a.offline_products:  # classifier test on archived product pages
    out = []
    for f in sorted(Path(a.offline_products).glob("product-*.html.gz")):
        html = gzip.decompress(f.read_bytes()).decode("utf-8", "ignore")
        iid = parse_product(html).item_id
        out.append({"file": f.name, **classify_product(html, "", iid)})
    print(json.dumps(out, indent=1, ensure_ascii=False))
    raise SystemExit(0)

if a.variant_check:
    pool = folded_not_seen(ck, a.raw_dir)
    step = max(1, len(pool) // a.variant_check)
    sample = pool[::step][:a.variant_check]  # evenly spread over the sorted pool (deterministic)
    print(f"{len(pool)} folded variant ids never seen in the run; sample {len(sample)} = {len(sample)} requests without retries")
    if not a.fetch:
        raise SystemExit(0)
    if a.max_requests <= 0:
        raise SystemExit("refusing to fetch without a positive --max-requests cap")

if a.offline:  # parser test on archived pages: every page is analysed on its own (no listing-level verdict)
    out = []
    for f in sorted(Path(a.offline).glob("listing-*.html.gz")):
        p = analyse_page(gzip.decompress(f.read_bytes()).decode("utf-8", "ignore"))
        folded = {v for vs in p["folded_variants"].values() for v in vs} - set(p["tile_ids"])
        kept = sum(1 for i in folded if ck.execute("SELECT 1 FROM items WHERE item_id=?", (i,)).fetchone())
        out.append({"file": f.name, **{k: v for k, v in p.items() if k not in ("tile_ids", "folded_variants")},
                    "folded_variant_ids": len(folded), "folded_variants_in_dataset": kept})
    (OUT / "offline-parser-test.json").write_text(json.dumps(out, indent=1), encoding="utf-8")
    print(json.dumps(out, indent=1))
    raise SystemExit(0)

if not a.fetch or a.max_requests <= 0:
    raise SystemExit("refusing to fetch without --fetch and a positive --max-requests cap")


async def main():
    from dotenv import load_dotenv
    from wmscraper.config import load_settings
    from wmscraper.fetch import FetchError, build_fetcher
    from wmscraper.runner import with_params

    load_dotenv(ROOT / ".env")
    s = load_settings(None)
    loc = s.location(a.location)
    params = {k: str(v).replace("{store_id}", loc.store_id) for k, v in (s.get("crawl.listing_params") or {}).items()}
    f = build_fetcher(s, loc)
    f.budget = a.max_requests  # hard cap, counted per attempt (retries included)
    await f.start()
    raw = OUT / "raw"
    raw.mkdir(exist_ok=True)
    results, index, stopped = [], [], ""
    if a.variant_check:
        try:
            for n, (iid, src) in enumerate(sample, 1):
                try:
                    res = await f.get(f"https://www.walmart.com/ip/{iid}")
                except FetchError as exc:
                    stopped = str(exc)
                    break
                name = f"V{n:03d}-{iid}.html.gz"
                (raw / name).write_bytes(gzip.compress(res.html.encode("utf-8")))
                try:
                    results.append({"file": name, "folded_in": src, **classify_product(res.html, res.final_url, iid)})
                except Exception as exc:
                    results.append({"file": name, "folded_in": src, "item_id": iid, "verdict": f"unparsed: {exc}"})
        finally:
            await f.close()
        (OUT / "variant-check.json").write_text(json.dumps(
            {"pool_folded_ids_never_seen": len(pool), "sampled": len(sample), "max_requests_cap": a.max_requests,
             "provider_requests_used": f.stats["requests"], "fetch_stats": f.stats, "stopped_early": stopped,
             "verdicts": dict(Counter(x["verdict"] for x in results)), "items": results}, indent=1, ensure_ascii=False),
            encoding="utf-8")
        print(json.dumps({"verdicts": dict(Counter(x["verdict"] for x in results)), "requests": f.stats["requests"]}))
        return
    try:
        for n, r in enumerate(rows, 1):
            pages = []
            for pg in wanted_pages(r):
                url = with_params(r["listing_url"], page=pg if pg > 1 else None, **params)
                try:
                    res = await f.get(url)
                except FetchError as exc:
                    stopped = str(exc)
                    break
                name = f"L{n:03d}-p{pg:02d}.html.gz"
                (raw / name).write_bytes(gzip.compress(res.html.encode("utf-8")))
                p = analyse_page(res.html, res.final_url)
                index.append({"file": name, "listing_url": r["listing_url"], "page": pg, "requested_url": url,
                              "fetched_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                              "walmart_total": p["walmart_total"], "max_page": p["max_page"], "location": p["location"]})
                pages.append(p)
            if pages:
                results.append(summarise(r, pages, ck))
            if stopped:
                break
    finally:
        await f.close()
    (OUT / "raw-index.json").write_text(json.dumps(index, indent=1), encoding="utf-8")
    write(results, {"run_id": a.run_id, "pages_mode": a.pages, "listings_selected": len(rows),
                    "listings_with_evidence": len(results), "max_requests_cap": a.max_requests,
                    "provider_requests_used": f.stats["requests"], "fetch_stats": f.stats, "stopped_early": stopped})


asyncio.run(main())
