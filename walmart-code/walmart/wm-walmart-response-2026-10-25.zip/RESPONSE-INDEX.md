# Walmart #32/#38 – response to the feedback of 24 October

This package answers the Walmart points of your 24 October feedback. It **supplements** `wm-delivery-v1.1.5-recheck.zip`, which stays the dataset and evidence package. Everything here was produced **offline** from the run's own checkpoint, logs and archived raw pages: **0 provider requests** were made, nothing was deployed, and no code was changed. Source stays 1.1.5 (`75d76e0e…`), and publication stays blocked.

| Your point | Short answer | Files |
|---|---|---|
| 175 short listings: raw pages, termination, counts, variants, caps | Pagination evidence for every listing is below. Raw first/last pages for all 175 need a bounded fetch (command and hard cap in §1.4) | `1-shortfall-175/` |
| Separate truly unexplained gaps from inflated totals; narrow exception | 80 listings meet the offline conditions; 95 stay blocking until raw evidence exists. The proposed rule is in §1.3 | `1-shortfall-175/short-listings-pagination.csv` |
| Source changes during the run vs the final hash; version of the hard-stop test | 5 versions, all re-verified. The live hard stop/resume ran on **1.1.1**, not on the final hash | `2-version-ledger/` |
| UPC gaps behind 2,781 / 58,312 | 2,781 have a UPC, 69 are source-absent and 55,462 are not yet fetched. Estimate in §3 | `3-upc-status/` |
| Fresh vs carried, unavailable products | 58,188 fresh, 124 carried with their original dates, 20,895 out of stock retained | `4-observations/` |
| Azure sequence, manual-only, prerequisites | Nothing has been deployed to your group yet. Sequence and blockers in §5 | this file |
| Completion plan in US Central time | §6 | this file |

---

## 1. The 175 short listings

### 1.1 What is already proven (both reads, store #100 on every page)
- All 175 were read to **Walmart's own `maxPage`** on the first read and again on the re-check (`stop_reason = walmart_last_page`). No listing stopped early, was capped, or hit a fetch error.
- Termination is page-based. Walmart's `paginationV2` has no cursor, so each listing ends when the page number reaches Walmart's `maxPage`. The scraper requests 40 products per page (`ps=40`).
- Counts are per listing in `short-listings-pagination.csv`:
  - Walmart's total on both reads.
  - Products served on both reads (product tiles; ad tiles such as `AdPlaceholder` are not counted).
  - Product tiles per page on the re-check.
  - The last page's tile count.
  - The gap.
- Every row is keyed by `listing_url`, so it joins to `recheck-before-after.csv`.
- Deduplication: products served counts tiles. Duplicates across listings are removed when products are stored: 220,012 duplicate sightings across the whole run, recorded in the checkpoint's `seen` table. Duplicates **within** a listing, and pinned tiles that repeat on a later page, can only be counted from raw pages (§1.4).

### 1.2 Classification from the evidence we already have
| Class | Listings | What the data shows |
|---|---|---|
| A – Walmart's pagination cannot hold its own total (`maxPage × 40 < total`) | 2 | Walmart reports more products than its own pages can show |
| B – Walmart served **fewer than 40 tiles on pages before its last page** | 165 | Walmart counts products in its total that it does not render on the pages it serves |
| C – every page full, gap unexplained | 3 | treated as truly unexplained |
| D – per-page counts not attributable from the log (two listings share name and page count) | 5 | need raw pages |

Further facts across the 175:
- **Walmart's total changed between the two reads on 147 listings.**
- Products served stayed within 3 between reads on 110.
- Median gap: 28 products; total gap: 6,810.

### 1.3 Proposed narrow exception (not implemented; for your decision)
A short listing may be published with a per-listing warning, **"Walmart total not served"**, only if **all** of these hold. Any other short listing keeps blocking publication. Coverage validation stays on for every listing.
1. It was read to Walmart's own `maxPage` on two independent reads, with store #100 verified on every page and no fetch errors.
2. Products served are stable between the reads, within the larger of 3 products or 2%.
3. Walmart served fewer than the requested 40 tiles on at least one page before its last page, or its page count cannot hold its total (classes A and B).
4. The gap is no more than 25% of the reachable total.
5. The raw-page evidence (§1.4) shows every served tile was collected or explicitly excluded, with the exclusion reason recorded.
6. The listings using the exception together stay below 5% of the products in the run, and each one is listed in the report.

On conditions 1–4 alone (the evidence available now), **80 listings with 2,096 products** would qualify. **95 listings with 4,714 products stay blocking**: 3 in class C, 5 in class D, and 87 that are unstable or have gaps over 25%. Condition 5 needs the raw pages.

### 1.4 Variants: an open question about scope (disclosed now)
The run archived page 1 of 4 store-pinned listings in Baby (`raw-samples/`, analysed in `folded-variant-analysis.json`). One of them, Huggies, is among the re-checked listings. The pages show that Walmart **folds size and colour variants into one tile**: `variantCriteria[].variantList[].selectedProduct.usItemId`.
- On those 4 pages, 161 tiles carry **484 folded variant item ids**.
- Of these, only 12 are in our dataset and 9 were seen and excluded as online-only.
- **463 (96%) were never served as their own tile anywhere in the 3,294 listings.**

Walmart's totals are close to the tile counts (Diapers: 297 total, about 308 tiles served), so folded variants do not explain the 175 gaps. They are a separate scope question: **if these variants are store #100 offers, the dataset misses them.** I have not assumed either way. The check below settles it.

### 1.5 Bounded evidence fetch: executable commands and enforced limits (needs your approval)
`1-shortfall-175/shortfall_evidence.py` is a helper outside the scraper source, so the hash is unchanged.
- It uses the scraper's own store-pinned fetcher and never writes to the run checkpoint.
- `--max-requests` is a hard cap that **includes retries**: the fetcher refuses request N+1.
- Without `--fetch`, it makes no requests.

```powershell
cd walmart-scraper                      # the 1.1.5 source with the run's output/ folder
$P="..\wm-walmart-response-2026-10-25\1-shortfall-175"
# E1 – every page of the 175 listings: 1,032 pages (plan prints this; no requests)
python $P\shortfall_evidence.py --scraper-dir . --csv $P\recheck-before-after.csv --out evidence-shortfall --pages all --plan
python $P\shortfall_evidence.py --scraper-dir . --csv $P\recheck-before-after.csv --out evidence-shortfall --pages all --fetch --max-requests 1100
# E2 – are folded variants store-100 offers? 100 product pages from the folded ids never seen in the run
python $P\shortfall_evidence.py --scraper-dir . --csv $P\recheck-before-after.csv --out evidence-variants --variant-check 100 `
  --raw-dir output\walmart-100-bentonville\runs\20261024T043517Z-fa478c\raw --raw-dir evidence-shortfall\raw --fetch --max-requests 120
```

E1 archives every raw page and writes `shortfall-evidence.csv`, tied to `recheck-before-after.csv` by `listing_url`, with:
- Walmart's total on every page.
- `maxPage`, and Walmart's re-rank page limit (`pap.polaris.ms_max_page_within_rerank`).
- Product, non-product and pinned tiles.
- Duplicates within the listing.
- Folded variant ids, each looked up in the run as kept, excluded (with reason) or never seen.
- A per-listing verdict: *explained by folded variants already in the dataset* / *partly explained* / *unexplained*.

E2 classifies each sampled variant as one of: store-100 offer (in scope), online-only, marketplace, or unconfirmed.

**Total for E1 + E2: at most 1,220 requests, about 1.5 hours.** The offline tests of both parsers are in `raw-samples/folded-variant-analysis.json` and were also run on the 5 archived product pages.

---

## 2. Source versions during the run, and the hard-stop test

`2-version-ledger/version-ledger.json` recomputes each source zip's fingerprint with the scraper's own algorithm and matches it to the hash every session wrote into the checkpoint. **All 5 match.** The zips and file-by-file patches are included.

| Version | source_sha256 | Changed from previous | Sessions (UTC, 24 Oct) | Listing pages collected |
|---|---|---|---|---|
| 1.1.1 | `b53b1a4e…` | – | 04:35 start; **hard kill without cleanup 04:44:48**; resumed 04:44:48 | 2,259 (301 before the kill) |
| 1.1.2 | `b9b9d3f5…` | `runner.py` (+44 −19): a node with subcategories is always split, planning in parallel; `settings.yaml` planning_concurrency; test | 06:21 resumed after the Food planning correction (event in the checkpoint) | 62 |
| 1.1.3 | `4ce14b30…` | `settings.yaml` concurrency values only | 06:28 resumed | 250 |
| 1.1.4 | `5c837c75…` | clean product URLs at output (`parse/walmart.py`, `checkpoint.py`), test | 06:51 and 08:34 resumed | 11,668 |
| 1.1.5 | `75d76e0e…` | "UPC pending" marking in one transaction (`checkpoint.py` +5, `runner.py` +1 −2) | 13:35 resumed (1,200 product pages); 15:56 re-check (1,158 listing pages, 114 product pages) | 5 + 1,158 |

- **The live hard stop and resume was performed on 1.1.1 (`b53b1a4e…`), not on the final 1.1.5.** Later sessions resumed the same run ID from the checkpoint on newer versions, but none of them was a hard stop.
- A hard stop on the final hash is planned in Azure (§6, step 6).
- Correction disclosed: the `dist/` copy of `walmart-scraper-1.1.1-src.zip` was rebuilt after the run started and does **not** reproduce `b53b1a4e`. The original, built at 04:33 UTC before the run, is in the run's evidence folder (zip sha `2393c11b…`). That original is the one included here.
- 1.1.2 changed how Food was planned. Food's listings planned under 1.1.1 were removed and Food was planned again (`05-planning-correction-event.json`).
- 1.1.3 to 1.1.5 do not change what is collected from a page: they cover concurrency, the output URL format and a transaction.
- 1.1.4 and 1.1.5 are the only versions whose code ran after 06:51. The output-URL cleaning in 1.1.4 is applied to every record at output.

## 3. UPCs: 2,781 of 58,312

`3-upc-status/upc-status-per-product.csv` gives one row per product.

| Status | Products |
|---|---|
| UPC from a product page with store #100 confirmed, this run | 1,663 |
| UPC reused from the verified v1.0.0 run (identity only, never prices) | 997 |
| UPC on carried-forward products | 121 |
| **Source-absent:** product page fetched, Walmart shows no UPC | 66 |
| **Source-absent:** carried product published without a UPC | 3 |
| **Not yet fetched** (queued; Walmart listings carry no UPC) | 55,462 |

- **Yield:** 96.2% of product pages fetched in this run showed a UPC, so about 56,100 products should have one once the queue is finished.
- **To complete:** 55,462 product pages, up to about 57,700 requests with variant retries.
  - At 1,200 per run: 47 runs, about 23 weeks at two runs a week.
  - As one pass: about 15–16 hours at the observed 60 pages a minute.
- **Dependency found:** a new run reuses known UPCs only from the **published** `latest/records.json`. While publication is blocked, scheduled runs would mostly re-fetch the same first products and the queue would not advance. The fix is in step 3 of the plan: resume the queued items, and reuse identity only (never prices) from the last run.

## 4. Fresh versus carried observations; unavailable products

`4-observations/fresh-vs-carried.json`:
- **58,188 fresh store offers**, observed 24 Oct on store-100 verified pages.
- **124 carried forward** with their original observation dates (81 from 19 Oct, 43 from 20 Oct), marked `last_observed`.
- **20,895 out-of-stock store products retained.** The re-check removed none.

## 5. Azure: what was done, the sequence, and what blocks it

- **Done so far:** the earlier Azure evidence (v1.0.0, 20 Oct) came from **my own subscription**, with a scheduled job. Nothing has been deployed to `scraper-contest-asif-test`, and nothing will be until you approve.
- **Code changes needed first.** The current template creates a twice-weekly schedule, creates the resource group, and makes 3 role assignments. Your Contributor role cannot make role assignments.
  - The final version will deploy a **manual-only** job, with no schedule.
  - It will use your existing group and skip the role assignments.
- **Sequence:** final code → deploy (manual-only) → provider probe → smoke test → hard stop and resume → deliberately failed run → full repeat → UPC pass. Each step has its own request cap and starts only after your approval.
- **Blockers we need you to resolve:**
  1. **Role assignments.** The job's managed identity needs Storage Blob Data Contributor on the storage account and Key Vault Secrets User on the vault, plus AcrPull only if a registry is used. Either you create them after deployment, or you grant a role-assignment role limited to the group.
  2. **Provider credential type.** The Walmart run used the Oxylabs Walmart endpoint `webapi.oxylabs.io/v1/scrape/walmart` with an API key (Bearer), sending `store_id=100` and `delivery_zip=72712`. The scraper also supports the Oxylabs realtime endpoint `realtime.oxylabs.io/v1/queries` with an API username and password (Basic). That path is **not verified for store pinning**.
     - Please check in the Oxylabs dashboard which of the two your Web Scraper API plan provides, and its quota.
     - You can enter the credential into the Key Vault yourself, so I never need to see it.
     - A probe of at most 10 requests (store page, canaries, one listing page) verifies store #100 pinning before anything larger runs.
  3. **Quota and a test window** for steps 6–8.

## 6. Completion plan (US Central Daylight Time, UTC−5)

| # | Task | Requests (cap) | Work | Depends on | Expected completion (CDT) |
|---|---|---|---|---|---|
| 1 | Raw-page evidence E1 and variant check E2 (§1.5) → **reviewable package B** | ≤ 1,220 | 1.5 h run + 2.5 h analysis | your approval of the 1,220 requests | **4 h after approval** – Mon 26 Oct 15:00 if approved by 11:00 |
| 2 | Your decision: exception rule (§1.3) and whether folded variants are in scope (from E2) | – | – | package B | assumed Tue 27 Oct 10:00 |
| 3 | v1.1.6 code: the agreed exception; raw first/last page archived for every failing listing; per-listing tile, duplicate and variant counts in the report; UPC queue fix (§3); manual-only Azure template; tests | 0 | 8 h (+6 h if variants must be collected) | step 2 | Tue 27 Oct 20:00 (Wed 28 Oct 14:00 with variant collection) |
| 4 | Provider probe on your Oxylabs credential | ≤ 10 | 0.5 h | credential type and quota (§5.2) | with step 5 |
| 5 | Deploy manual-only to `scraper-contest-asif-test` | 0 | 1 h | step 3, role assignments (§5.1), your go-ahead | Wed 28 Oct 12:00 |
| 6 | Azure tests on the final hash: smoke test (≤60); **hard stop and resume** (stop the execution mid-run, start again; ≤150); deliberately failed run (≤40) | ≤ 250 | 3 h | step 5 | Wed 28 Oct 16:00 |
| 7 | Azure full repeat traversal on the final hash, started manually | ≈ 17,000 (+ variant pages if in scope) | 10–12 h + 3 h validation | quota and window approval | Thu 29 Oct 12:00 |
| 8 | UPC pass on the queued products | ≈ 55,500–57,700 | ≈ 16 h | quota approval | Fri 30 Oct 06:00 (or about 23 weeks at 1,200 per scheduled run) |
| 9 | **Final evidence package**, all on one hash | 0 | 4 h | steps 7–8 | **Fri 30 Oct 18:00** |

- **Next reviewable package:** package B, 4 hours after you approve step 1.
- **Final evidence package:** Fri 30 Oct 2026, 18:00 CDT. This assumes steps 1–2 and the Azure prerequisites are cleared by Tue 27 Oct 12:00 CDT; each day of delay moves it by a day.
- **Requests needed to finish:** about 1,220 + 260 + 17,000 + 57,700 ≈ 76,000. Nothing is spent without your approval.
