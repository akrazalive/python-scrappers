"""Run orchestration for one location.

Phases (each resumable from the checkpoint):
  1. lock          – refuse to start if another run for this location is active
  2. store         – fetch the store page, confirm id / name / address / ZIP
  3. canary:start  – known items must show a local (pickup / in-store) Walmart offer
  4. discovery     – category pages → subcategory listings (CSV exclusions applied)
  5. listings      – paginate every listing; per page: shape check, store check,
                     filter sponsored / marketplace / shipping-only / approx-weight, dedup
  6. enrichment    – product pages: UPC, size, store-level offer re-check, deals
  7. canary:end
  8. validate      – publish to latest/ only if every check passes
"""
from __future__ import annotations

import asyncio
import logging
import re
import time
import uuid
from datetime import datetime, timezone
from urllib.parse import urlencode, urlparse, parse_qsl, urlunparse

from .checkpoint import Checkpoint
from .config import Category, Location, Settings
from .fetch import FetchError, build_fetcher
from .lock import run_lock
from .models import Record
from .parse import deals
from .parse.text import clean_text, extract_weight, format_price, is_approximate_weight, is_private_label
from .parse.walmart import (ChallengeError, ListingItem, ShapeError, category_id_of, children_of, department_children,
                            discover_links, next_data, parse_listing, parse_product, parse_store, store_context_excerpt)
from .report import build_report
from .storage import build_storage
from .validate import validate_run
from .version import version_info

log = logging.getLogger("wmscraper.run")


def with_params(url: str, **params) -> str:
    u = urlparse(url)
    q = [(k, v) for k, v in parse_qsl(u.query) if k not in params and k != "povid"]
    q += [(k, str(v)) for k, v in params.items() if v not in (None, "")]
    return urlunparse(u._replace(query=urlencode(q)))


class Run:
    def __init__(self, settings: Settings, location: Location, run_id: str | None = None,
                 categories: list[Category] | None = None, limit: int = 0, demo: bool = False):
        self.s = settings
        self.loc = location
        self.crawl = {**(settings.get("crawl") or {}), **dict(location.crawl)}  # location overrides win
        self.categories = categories or settings.categories_for(location)
        self.limit = limit or int(settings.get("crawl.max_products_per_run", 0))
        self.demo = demo
        self.storage = build_storage(settings)
        prefix = f"{location.key}/runs/"
        if run_id is None:
            run_id = self._resumable_run() or datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:6]
        self.run_id = run_id
        self.prefix = prefix + run_id
        self.ck = Checkpoint(self._checkpoint_path())
        self.crawl_date = self.ck.get("crawl_date") or datetime.now(timezone.utc).date().isoformat()
        self.ck.set("crawl_date", self.crawl_date)
        self.store: dict = self.ck.get("store_verification") or {}

    # ------------------------------------------------------------------ helpers
    def _archive(self, kind: str, res, note: str = "") -> None:
        """Keep raw source responses (gzip) + a store-context excerpt as evidence. Bounded per kind."""
        import gzip
        import hashlib

        limit = int(self.s.get("evidence.raw_samples_per_kind", 5))
        counts = self.ck.get("raw_counts", {})
        if counts.get(kind, 0) >= limit:
            return
        counts[kind] = counts.get(kind, 0) + 1
        self.ck.set("raw_counts", counts)
        name = f"{kind}-{counts[kind]:02d}"
        body = res.html.encode("utf-8")
        self.storage.put_bytes(f"{self.prefix}/raw/{name}.html.gz", gzip.compress(body))
        try:
            excerpt = store_context_excerpt(next_data(res.html, res.final_url))
        except Exception as exc:  # archived even when unparsable – that is evidence too
            excerpt = [{"error": str(exc)}]
        index = self.storage.get_json(f"{self.prefix}/raw/index.json") or []
        index.append({"file": f"{name}.html.gz", "kind": kind, "url": res.url, "final_url": res.final_url,
                      "status": res.status, "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest(),
                      "fetched_at": datetime.now(timezone.utc).isoformat(timespec="seconds"), "note": note,
                      "store_context": excerpt})
        self.storage.put_json(f"{self.prefix}/raw/index.json", index)

    def _checkpoint_path(self):
        local = self.storage.local_path(f"{self.prefix}/checkpoint.sqlite")
        if local:
            return local
        # Azure: work on a local copy and upload it after every committed page
        from pathlib import Path
        p = Path("/tmp") / self.prefix.replace("/", "_") / "checkpoint.sqlite"
        p.parent.mkdir(parents=True, exist_ok=True)
        data = self.storage.get_bytes(f"{self.prefix}/checkpoint.sqlite")
        if data:
            p.write_bytes(data)
        return p

    def _sync_checkpoint(self):
        if not self.storage.local_path(f"{self.prefix}/checkpoint.sqlite"):
            self.ck.db.commit()
            self.storage.put_bytes(f"{self.prefix}/checkpoint.sqlite", self.ck.path.read_bytes())

    def _resumable_run(self) -> str | None:
        state = self.storage.get_json(f"{self.loc.key}/state.json") or {}
        return state.get("open_run")

    def _set_state(self, open_run: str | None):
        state = self.storage.get_json(f"{self.loc.key}/state.json") or {}
        state["open_run"] = open_run
        self.storage.put_json(f"{self.loc.key}/state.json", state)

    # ------------------------------------------------------------------ main
    async def execute(self) -> dict:
        t0 = time.monotonic()
        with run_lock(self.storage, self.loc.key):
            self._set_state(self.run_id)
            resumed = bool(self.ck.listings())
            if resumed:
                pending = self.ck.pending_listings()
                self.ck.event("run_resumed", {"pending_listings": len(pending), "items_already_kept": self.ck.count_items(),
                                              "next_pages": [[c, s, p] for c, s, _u, p in pending[:20]]})
            log.info("run_start", extra={"run_id": self.run_id, "location": self.loc.key, "store_id": self.loc.store_id,
                                         "fulfillment": self.loc.fulfillment, "resumed": resumed,
                                         "items_already_kept": self.ck.count_items(), **version_info()})
            self.fetcher = build_fetcher(self.s, self.loc)
            await self.fetcher.start()
            self.aborted = ""
            try:
                await self.verify_store()
                await self.canary("start")
                await self.discover()
                await self.crawl_listings()
                if self.crawl.get("enrich_product_pages", True):
                    await self.enrich()
                await self.canary("end")
            except Exception as exc:  # report, keep checkpoint, stay resumable
                self.aborted = f"{type(exc).__name__}: {exc}"
                self.ck.event("run_aborted", {"error": self.aborted})
                log.exception("run_aborted")
            finally:
                await self.fetcher.close()
            runtime = float(self.ck.get("runtime_total", 0)) + time.monotonic() - t0
            self.ck.set("runtime_total", runtime)
            self._sync_checkpoint()
            return self.finish(runtime)

    def finish(self, runtime: float) -> dict:
        records = self.ck.records()
        previous = self.storage.get_json(f"{self.loc.key}/latest/report.json")
        validation = validate_run(self.s, self.ck, records, self.categories, previous)
        if getattr(self, "aborted", ""):
            validation.fail(f"run aborted: {self.aborted} (checkpoint kept – next run resumes)")
        if self.demo:
            validation.warn("DEMO run (category subset / record limit) – never published to latest/")
        report = build_report(self.run_id, self.loc, self.store, self.ck, records, runtime,
                              self.fetcher.stats, validation.as_dict(), self.s)
        self.storage.put_json(f"{self.prefix}/records.json", records)
        self.storage.put_json(f"{self.prefix}/report.json", report)
        published = None
        if validation.ok and not self.demo:
            published = self.storage.publish(self.loc.key, self.run_id, records, report)
            log.info("published", extra=published)
        else:
            log.error("not_published", extra={"run_id": self.run_id, "errors": validation.errors[:20], "demo": self.demo})
        if not getattr(self, "aborted", "") or self.demo:
            self._set_state(None)  # aborted production runs stay open for resumption
        report["published"] = published
        self.storage.put_json(f"{self.prefix}/report.json", report)
        log.info("run_end", extra={"run_id": self.run_id, "records": len(records), "ok": validation.ok,
                                   "runtime_s": round(runtime, 1)})
        return report

    # ------------------------------------------------------------------ phases
    async def verify_store(self):
        if self.store.get("verified"):
            return
        url = f"https://www.walmart.com/store/{self.loc.store_id}"
        try:
            res = await self.fetcher.get(url)
            self._archive("store", res, "store verification page")
            info = parse_store(res.html, self.loc.store_id, res.final_url)
        except (FetchError, ShapeError, ChallengeError) as exc:
            self.store = {"verified": False, "reason": str(exc), "url": url}
            self.ck.set("store_verification", self.store)
            raise RuntimeError(f"store verification failed: {exc}") from exc
        problems = []
        if self.loc.zipcode and info.zipcode != self.loc.zipcode:
            problems.append(f"ZIP {info.zipcode} != configured {self.loc.zipcode}")
        if self.loc.expected_address and self.loc.expected_address.lower() not in info.address.lower():
            problems.append(f"address '{info.address}' does not contain configured '{self.loc.expected_address}'")
        zip_ok = not problems
        self.store = {"verified": zip_ok, "store_id": info.store_id, "store_name": info.name,
                      "store_location": info.address, "zipcode": info.zipcode, "url": url,
                      "checked_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                      "reason": "; ".join(problems)}
        self.ck.set("store_verification", self.store)
        log.info("store_verified" if zip_ok else "store_mismatch", extra=self.store)
        if not zip_ok:
            raise RuntimeError(self.store["reason"])

    def _check_context(self, store_ids: set[str], where: str) -> bool:
        if self.loc.store_id in store_ids:
            self.ck.set("store_verified_pages", self.ck.get("store_verified_pages", 0) + 1)
            return True
        self.ck.set("store_mismatches", self.ck.get("store_mismatches", 0) + 1)
        self.ck.event("store_mismatch", {"where": where, "found": sorted(store_ids)[:10]})
        log.error("store_context_mismatch", extra={"where": where, "found": sorted(store_ids)[:10]})
        return False

    async def canary(self, phase: str):
        items = list(self.loc.canary_items)
        self.ck.set("canary_configured", bool(items))
        if not items:
            return
        state = self.ck.get("canary", {})
        if state.get(phase, {}).get("ok"):
            return
        problems = []
        for item_id in items:
            try:
                res = await self.fetcher.get(f"https://www.walmart.com/ip/{item_id}")
                p = parse_product(res.html, res.final_url)
                if self.loc.store_id not in p.store_ids:
                    problems.append(f"{item_id}: store context missing")
                elif not p.current_price:
                    problems.append(f"{item_id}: no price")
            except Exception as exc:
                problems.append(f"{item_id}: {exc}")
        state[phase] = {"ok": not problems, "detail": problems, "items": items}
        self.ck.set("canary", state)
        log.info("canary", extra={"phase": phase, "ok": not problems, "problems": problems})
        if problems and len(problems) == len(items):
            raise RuntimeError(f"all canary items failed at {phase} – likely blocked or wrong store")

    def _listing_url(self, cid: str) -> str:
        return f"https://www.walmart.com/browse/{cid}"

    async def _root_id(self, cat) -> str:
        """Real category id for a CSV URL. /browse/ URLs carry it; /cp/ landing pages carry only their own node id
        (e.g. /cp/feeding/133283 -> category path 5427_133283), which is resolved from the page's own links."""
        cid = cat.category_id
        if "/cp/" not in cat.url or "_" in cid:
            return cid
        try:
            res = await self.fetcher.get(cat.url.split("?")[0])
            self._archive("category", res, f"{cat.name} landing page")
            data = next_data(res.html, res.final_url)
            paths = [category_id_of(u) for _n, u in discover_links(data, res.html)]
            paths += [k for _n, k in department_children(data)]
        except (FetchError, ShapeError, ChallengeError) as exc:
            log.warning("root_id_unresolved", extra={"category": cat.name, "error": str(exc)})
            return cid
        roots = sorted({"_".join(p.split("_")[: p.split("_").index(cid) + 1]) for p in paths if cid in p.split("_")},
                       key=len)
        root = roots[0] if roots else cid
        log.info("category_root", extra={"category": cat.name, "csv_id": cid, "root_id": root})
        return root

    async def discover(self):
        """Category -> listings. Each node is opened as a store-scoped listing; if Walmart reports more
        products than the reachable page window (pages x page size), its Departments facet children are
        crawled instead, so no product is hidden behind Walmart's page cap."""
        if self.ck.get("discovery_done"):
            return
        depth_max = int(self.crawl.get("subcategory_max_depth", 4))
        # splitting always uses Walmart's real page window, even when a scoped run crawls fewer pages
        max_pages = int(self.s.get("crawl.max_pages_per_listing", 25))
        per_cat = int(self.crawl.get("max_listings_per_category", 0))  # 0 = all (production)
        skip = [re.compile(p, re.I) for p in self.crawl.get("skip_subcategory_patterns") or []]
        extra = self._listing_params()
        for cat in self.categories:
            excluded = {e.lower() for e in cat.excluded_subcategories}
            leaves: list[tuple[str, str]] = []
            root = await self._root_id(cat)
            stack = [(cat.name, self._listing_url(root), root, 0)]
            seen = set()
            while stack and not (per_cat and len(leaves) >= per_cat):
                name, url, cid, depth = stack.pop(0)
                if cid in seen:
                    continue
                seen.add(cid)
                try:
                    res = await self.fetcher.get(with_params(url, **extra))
                    lp = parse_listing(res.html, res.final_url)
                except ShapeError as exc:
                    # Walmart serves some department nodes as landing pages: split into their child categories
                    kids = self._landing_children(res, cid, excluded, skip)
                    if kids and depth < depth_max:
                        stack[0:0] = [(n, self._listing_url(k), k, depth + 1) for n, k in kids]
                        log.info("landing_page_split", extra={"category": cat.name, "node": name, "children": len(kids)})
                    else:
                        self.ck.add_listing(cat.name, name, url)
                        self.ck.fail_listing(cat.name, url, f"discovery failed: {exc}")
                        log.error("discovery_failed", extra={"category": cat.name, "url": url, "error": str(exc)})
                    continue
                except (FetchError, ChallengeError) as exc:
                    self.ck.add_listing(cat.name, name, url)
                    self.ck.fail_listing(cat.name, url, f"discovery failed: {exc}")
                    log.error("discovery_failed", extra={"category": cat.name, "url": url, "error": str(exc)})
                    continue
                reachable = max_pages * max(len(lp.items), 1)
                window = max_pages * int(self.crawl.get("page_size", 40))  # products 25 pages can expose
                kids = [(n, k) for n, k in lp.children if k.startswith(cid + "_")
                        and n.lower() not in excluded and not any(p.search(n) for p in skip)]
                ids = {k for _n, k in kids}
                kids = [(n, k) for n, k in kids if not any(k != o and k.startswith(o + "_") for o in ids)]  # direct only
                if lp.total_count > reachable and kids and depth < depth_max:
                    stack[0:0] = [(n, self._listing_url(k), k, depth + 1) for n, k in kids]  # depth-first
                    log.info("category_split", extra={"category": cat.name, "node": name, "walmart_total": lp.total_count,
                                                      "children": len(kids)})
                elif lp.total_count > window and self.crawl.get("price_partitioning", True):
                    # no further subcategories but more products than 25 pages can show -> partition by price
                    parts = await self._price_partitions(cat.name, name if depth else cat.name, url, window)
                    leaves += parts
                else:
                    leaves.append((name if depth else cat.name, url))
            if self.loc.only_subcategories:
                keep = {x.lower() for x in self.loc.only_subcategories}
                leaves = [(n, u) for n, u in leaves if n.lower() in keep]
                if not leaves:
                    self.ck.add_listing(cat.name, cat.name, cat.url)
                    self.ck.fail_listing(cat.name, cat.url, f"none of the scoped subcategories found: {sorted(keep)}")
            for sub, url in leaves:
                self.ck.add_listing(cat.name, sub, url)
            log.info("category_discovered", extra={"category": cat.name, "listings": len(leaves), "excluded": sorted(excluded)})
        self.ck.set("discovery_done", True)
        self._sync_checkpoint()

    async def crawl_listings(self):
        max_pages = int(self.crawl.get("max_pages_per_listing", 25))
        self.ck.set("pages_per_listing", max_pages)  # validation measures thinness against what this run crawls
        extra = self._listing_params()
        for category, sub, url, next_page in self.ck.pending_listings():
            page = next_page
            while True:
                if self.limit and self.ck.count_items() >= self.limit:
                    log.info("limit_reached", extra={"limit": self.limit})
                    return
                page_url = with_params(url, page=page if page > 1 else None, **extra)
                try:
                    res = await self.fetcher.get(page_url)
                    self._archive("listing", res, f"{category} / {sub} page {page}")
                    lp = parse_listing(res.html, res.final_url)
                except (FetchError, ShapeError, ChallengeError) as exc:
                    self.ck.fail_listing(category, url, f"page {page}: {exc}")
                    log.error("listing_failed", extra={"category": category, "sub_category": sub, "page": page, "error": str(exc)})
                    break
                if not self._check_context(lp.store_ids, page_url):
                    self.ck.fail_listing(category, url, f"page {page}: store context mismatch")
                    break
                accepted, skipped = [], []
                self._census([(it.item_id, t) for it in lp.items for t in it.promo_texts], "listing")
                for it in lp.items:
                    reason = self._reject_reason(it)
                    if reason:
                        skipped.append((it.item_id, reason))
                    else:
                        accepted.append((it.item_id, sub, self._record(it, category, sub)))
                last = page >= min(lp.max_page, max_pages) or not lp.items
                capped = lp.max_page > max_pages
                new = self.ck.commit_page(category, url, page, lp.max_page, accepted, skipped, sub, last, capped,
                                          reported_total=lp.total_count, page_size=len(lp.items))
                log.info("page", extra={"category": category, "sub_category": sub, "page": page, "max_page": lp.max_page,
                                        "items": len(lp.items), "kept_new": new, "skipped": len(skipped), "total": self.ck.count_items()})
                self._sync_checkpoint()
                if last:
                    break
                page += 1

    async def _price_partitions(self, category: str, sub: str, url: str, window: int) -> list[tuple[str, str]]:
        """Split an oversize listing into price bands (Walmart min_price / max_price) until every band fits the
        page window, so the whole listing is paginated to exhaustion. Bands overlap only at the boundary price;
        overlapping items are removed by item-id dedup."""
        edges = [float(x) for x in self.crawl.get("price_band_edges", [0, 3, 5, 10, 20, 50, 100, 100000])]
        bands = list(zip(edges[:-1], edges[1:]))
        out: list[tuple[str, str]] = []
        extra = self._listing_params()
        while bands:
            lo, hi = bands.pop(0)
            band_url = with_params(url, min_price=f"{lo:g}", max_price=f"{hi:g}")
            try:
                res = await self.fetcher.get(with_params(band_url, **extra))
                total = parse_listing(res.html, res.final_url).total_count
            except (FetchError, ShapeError, ChallengeError) as exc:
                self.ck.add_listing(category, sub, band_url)
                self.ck.fail_listing(category, band_url, f"price band failed: {exc}")
                continue
            if total > window and hi - lo > 0.5:
                mid = round((lo + hi) / 2 if hi < 100000 else lo * 2 + 50, 2)
                bands[0:0] = [(lo, mid), (mid, hi)]
                continue
            if total > window:
                log.warning("price_band_still_capped", extra={"category": category, "sub_category": sub, "band": [lo, hi],
                                                              "walmart_total": total})
            if total:
                out.append((sub, band_url))
            self.ck.event("price_band", {"category": category, "sub_category": sub, "band": [lo, hi], "walmart_total": total})
        log.info("price_partitioned", extra={"category": category, "sub_category": sub, "bands": len(out)})
        return out

    @staticmethod
    def _landing_children(res, cid: str, excluded: set, skip: list) -> list[tuple[str, str]]:
        try:
            data = next_data(res.html, res.final_url)
        except (ShapeError, ChallengeError):
            return []
        pairs = [(n, category_id_of(u)) for n, u in discover_links(data, res.html)] + department_children(data)
        kids, seen = [], set()
        for n, k in pairs:
            if k.startswith(cid + "_") and k not in seen and n and n.lower() not in excluded \
                    and not any(p.search(n) for p in skip) and n.lower() not in ("view all", "shop all", "shop now", "see all"):
                seen.add(k)
                kids.append((n, k))
        ids = {k for _n, k in kids}
        return [(n, k) for n, k in kids if not any(k != o and k.startswith(o + "_") for o in ids)]

    def _census(self, pairs: list[tuple[str, str]], where: str) -> None:
        """Offer census: every promotion / badge label Walmart displayed, with counts and example item ids."""
        if not pairs:
            return
        census = self.ck.get("offer_census", {})
        for item_id, text in pairs:
            e = census.setdefault(text, {"count": 0, "examples": [], "seen_on": []})
            e["count"] += 1
            if len(e["examples"]) < 3 and item_id not in e["examples"]:
                e["examples"].append(item_id)
            if where not in e["seen_on"]:
                e["seen_on"].append(where)
        self.ck.set("offer_census", census)

    def _listing_params(self) -> dict:
        return {k: str(v).replace("{store_id}", self.loc.store_id) for k, v in (self.crawl.get("listing_params") or {}).items()}

    def _reject_reason(self, it: ListingItem) -> str:
        # Sponsored placements are real products: kept once (item-id dedup), never duplicated.
        if it.is_marketplace:
            return "marketplace_seller"
        if not it.local_at(self.loc.store_id):
            return "shipping_only_or_not_at_store"
        if it.approx_weight or is_approximate_weight(it.title):
            return "approximate_weight"
        return ""

    def _record(self, it: ListingItem, category: str, sub: str) -> dict:
        regular, sale = (it.was_price, it.current_price) if it.was_price else (it.current_price, "")
        d = deals.classify(it.promo_texts)
        rec = Record(
            zipcode=self.store.get("zipcode", self.loc.zipcode), store_name=self.store.get("store_name", ""),
            store_location=self.store.get("store_location", ""), store_logo=self.s.get("store_logo_url", ""),
            store_brand="yes" if is_private_label(it.brand, it.title, self.s.private_label_brands) else "no",
            category=category, sub_category=sub, product_title=it.title, weight=extract_weight(it.title),
            regular_price=format_price(regular), sale_price=format_price(sale),
            volume_deals_description=d.volume_description, volume_deals_price=d.volume_price,
            digital_deals_description=d.digital_description, digital_deals_price=d.digital_price,
            image_url=it.image_url, url=it.url, upc=it.upc, ppm=it.ppm, crawl_date=self.crawl_date,
        )
        return rec.to_ordered_dict()

    async def enrich(self):
        """Product pages: UPC, displayed size, store-level offer re-check, product-page deals."""
        sem = asyncio.Semaphore(int(self.s.get("fetch.concurrency", 1)))

        async def one(item_id, rec):
            async with sem:
                await self._enrich_one(item_id, rec)

        await asyncio.gather(*(one(i, r) for i, r in self.ck.unenriched()))

    async def _enrich_one(self, item_id: str, rec: dict):
        """One product page: identity check, UPC, size, store re-check, seller re-check, deals."""
        try:
            res = await self.fetcher.get(rec["url"])
            self._archive("product", res, rec["product_title"][:80])
            p = parse_product(res.html, res.final_url)
            attempts = [(rec["url"], res.final_url, p.item_id)]
            if p.item_id != item_id:  # Walmart served another variant: retry the canonical item URL once
                res = await self.fetcher.get(f"https://www.walmart.com/ip/{item_id}")
                p = parse_product(res.html, res.final_url)
                attempts.append((f"https://www.walmart.com/ip/{item_id}", res.final_url, p.item_id))
            match = p.item_id == item_id
            log.info("product_identity", extra={
                "item_id": item_id, "match": match, "attempts": attempts, "response_item_id": p.item_id,
                "response_name": p.name, "response_upc": p.upc, "output_title": rec["product_title"],
                "decision": "enriched" if match else "variant_mismatch_kept_listing_data"})
            if not match:
                self.ck.event("variant_mismatch", {"item_id": item_id, "attempts": attempts, "response_name": p.name})
                self.ck.update_item(item_id, rec, enriched=3)  # listing data only; product page never attributed
                return
            self._census([(item_id, t) for t in p.promo_texts], "product")
        except (FetchError, ShapeError, ChallengeError) as exc:
            self.ck.event("enrich_failed", {"item_id": item_id, "error": str(exc)})
            log.warning("enrich_failed", extra={"item_id": item_id, "error": str(exc)})
            self.ck.update_item(item_id, rec, enriched=2)  # kept from listing data, flagged
            return
        if not self._check_context(p.store_ids, rec["url"]):
            self.ck.update_item(item_id, None)
            return
        if p.seller_id or p.seller_name:
            tmp = ListingItem(item_id, "", "", "", "", "", "", "", p.seller_name, p.seller_id, False, [], [])
            if tmp.is_marketplace:
                self.ck.update_item(item_id, None)
                self.ck.event("dropped_marketplace_on_pdp", {"item_id": item_id})
                return
        weight = p.size if p.size and not p.size.replace(".", "").isdigit() else (rec["weight"] or
                  (f"{p.size} count" if p.size else ""))
        if is_approximate_weight(weight):
            self.ck.update_item(item_id, None)
            self.ck.event("dropped_approx_weight", {"item_id": item_id, "weight": weight})
            return
        rec["upc"] = rec["upc"] or p.upc  # original UPC preserved, never altered
        rec["weight"] = clean_text(weight)
        rec["ppm"] = rec["ppm"] or p.ppm  # only as displayed; never computed
        rec["image_url"] = rec["image_url"] or p.image_url
        if p.brand and rec["store_brand"] == "no":
            rec["store_brand"] = "yes" if is_private_label(p.brand, rec["product_title"], self.s.private_label_brands) else "no"
        if not (rec["volume_deals_description"] or rec["digital_deals_description"]):
            d = deals.classify(p.promo_texts)
            rec.update(volume_deals_description=d.volume_description, volume_deals_price=d.volume_price,
                       digital_deals_description=d.digital_description, digital_deals_price=d.digital_price)
        self.ck.update_item(item_id, rec, enriched=1)
        self._sync_checkpoint()


def run_location(settings: Settings, location_key: str, **kw) -> dict:
    loc = settings.location(location_key)
    return asyncio.run(Run(settings, loc, **kw).execute())
