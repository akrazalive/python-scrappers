"""Walmart location-specific product scraper for Microsoft Azure."""

__version__ = "1.0.0"
