"""Run report: everything the contest asks to see, generated from the checkpoint."""
from __future__ import annotations

from collections import Counter

from .validate import completeness
from .version import version_info


def _category_completeness(listings, records) -> dict:
    """Per category: listings done/failed, Walmart-reported vs collected, kept records, key-field fill rates."""
    out = {}
    for l in listings:
        c = out.setdefault(l["category"], {"listings": 0, "listings_done": 0, "listings_failed": 0,
                                           "walmart_reported": 0, "collected": 0, "kept_records": 0})
        c["listings"] += 1
        c["listings_done"] += l["status"] == "done"
        c["listings_failed"] += l["status"] == "failed"
        c["walmart_reported"] += l.get("reported_total") or 0
        c["collected"] += l["seen"]
    for cat, c in out.items():
        recs = [r for r in records if r["category"] == cat]
        c["kept_records"] = len(recs)
        n = len(recs) or 1
        c["fill"] = {f: round(sum(1 for r in recs if r[f]) / n, 3) for f in ("upc", "ppm", "weight", "image_url", "regular_price")}
    return out


def _examples(records, predicate, n=5):
    return [r for r in records if predicate(r)][:n]


def build_report(run_id: str, location, store: dict, ck, records: list[dict], runtime_s: float,
                 fetch_stats: dict, validation: dict, settings) -> dict:
    reasons = ck.skip_reasons()
    listings = ck.listings()
    by_cat = Counter(r["category"] for r in records)
    by_sub = Counter(f"{r['category']} > {r['sub_category']}" for r in records)
    urls = Counter(r["url"] for r in records)
    return {
        "run_id": run_id,
        "scraper": version_info(),
        "location": {"key": location.key, "store_id": location.store_id, "zipcode": location.zipcode,
                     "fulfillment": location.fulfillment},
        "store_verification": store,
        "fulfillment_context": {
            "listing_filter": settings.get("crawl.listing_params"),
            "store_mismatch_pages": ck.get("store_mismatches", 0),
            "pages_with_store_verified": ck.get("store_verified_pages", 0),
        },
        "runtime_seconds": round(runtime_s, 1),
        "total_unique_records": len(records),
        "duplicate_records_in_output": sum(c - 1 for c in urls.values() if c > 1),
        "duplicates_prevented": reasons.get("duplicate", 0),
        "excluded": {k: v for k, v in reasons.items() if k not in ("kept", "duplicate")},
        "count_by_category": dict(sorted(by_cat.items())),
        "count_by_subcategory": dict(sorted(by_sub.items())),
        "listings": listings,
        "field_completeness": completeness(records),
        "category_completeness": _category_completeness(listings, records),
        "examples": {
            "ppm": _examples(records, lambda r: r["ppm"]),
            "volume_deals": _examples(records, lambda r: r["volume_deals_description"]),
            "digital_deals": _examples(records, lambda r: r["digital_deals_description"]),
            "sale_price": _examples(records, lambda r: r["sale_price"]),
            "no_deals": _examples(records, lambda r: not (r["volume_deals_description"] or r["digital_deals_description"] or r["sale_price"])),
            "private_label": _examples(records, lambda r: r["store_brand"] == "yes"),
        },
        "fetch_stats": fetch_stats,
        "canary": ck.get("canary", {}),
        "validation": validation,
        "events_tail": [dict(zip(("ts", "kind", "detail"), e)) for e in ck.db.execute(
            "SELECT ts, kind, detail FROM events ORDER BY rowid DESC LIMIT 50").fetchall()],
    }
