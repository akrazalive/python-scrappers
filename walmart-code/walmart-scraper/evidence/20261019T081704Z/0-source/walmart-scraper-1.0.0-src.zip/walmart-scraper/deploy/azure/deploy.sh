#!/usr/bin/env bash
# One-command deployment into an existing Azure subscription.
#   ./deploy/azure/deploy.sh <resource-group> <region> [image-tag]
# Provider secrets are read from the environment (never passed on the command line history):
#   export OXYLABS_USERNAME=... OXYLABS_PASSWORD=...   (or ZYTE_API_KEY=...)
set -euo pipefail
RG=${1:?resource group}; REGION=${2:?region e.g. eastus}; TAG=${3:-1.0.0}
HERE="$(cd "$(dirname "$0")" && pwd)"; ROOT="$HERE/../.."

az group create -n "$RG" -l "$REGION" -o none

echo "1/3 infrastructure"
OUT=$(az deployment group create -g "$RG" -f "$HERE/main.bicep" \
  -p oxylabsUsername="${OXYLABS_USERNAME:-}" oxylabsPassword="${OXYLABS_PASSWORD:-}" zyteApiKey="${ZYTE_API_KEY:-}" \
  --query properties.outputs -o json)
ACR=$(echo "$OUT" | python -c "import json,sys;print(json.load(sys.stdin)['acrLoginServer']['value'])")
JOB=$(echo "$OUT" | python -c "import json,sys;print(json.load(sys.stdin)['jobName']['value'])")

echo "2/3 build image in ACR (no local Docker needed)"
az acr build -r "${ACR%%.*}" -t "wmscraper:$TAG" "$ROOT" -o none

echo "3/3 point the scheduled job at the image"
az deployment group create -g "$RG" -f "$HERE/main.bicep" \
  -p image="$ACR/wmscraper:$TAG" oxylabsUsername="${OXYLABS_USERNAME:-}" oxylabsPassword="${OXYLABS_PASSWORD:-}" zyteApiKey="${ZYTE_API_KEY:-}" -o none

echo "Deployed. Job: $JOB  (schedule Mon+Thu 06:00 UTC)"
echo "Start a run now:   az containerapp job start -g $RG -n $JOB"
echo "Execution history: az containerapp job execution list -g $RG -n $JOB -o table"
