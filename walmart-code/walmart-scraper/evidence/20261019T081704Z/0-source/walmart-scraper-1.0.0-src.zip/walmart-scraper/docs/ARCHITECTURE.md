# Architecture

```
 Azure Container Apps Job (cron Mon+Thu 06:00 UTC, parallelism 1)
   └─ python -m wmscraper run-all            ── for each enabled location in config/locations.yaml
        1 lock          Blob lease per location → overlapping runs are impossible
        2 store         /store/<id> → id, name, address, ZIP must match config
        3 canary:start  known items must show a local Walmart offer at this store
        4 discovery     category pages → subcategory listings (CSV exclusions applied)
        5 listings      every page: shape check · store check · filters · dedup → checkpoint
        6 enrichment    product page: UPC, size, store re-check, marketplace re-check, deals
        7 canary:end
        8 validate      all checks pass → publish latest/  ·  otherwise keep last good data
   Fetch layer: pacing · retries + backoff · challenge / tiny-page / latency detection
   Provider: Oxylabs | Zyte | Playwright (selected in settings.yaml, secrets in Key Vault)
   Storage: Blob  <location>/runs/<run_id>/…   <location>/latest/…   checkpoint.sqlite
   Logs: JSON lines → Log Analytics (store, category progress, retries, errors, counts, status)
```

## Data-quality rules

| Requirement | Implementation |
|---|---|
| Correct store | Store page verified before collection; **every** listing and product page must carry the configured store id. Any mismatch fails the listing and blocks publication. |
| Local pickup / in-store context | Listings requested with the Pickup fulfillment facet; items kept only if a pickup / in-store badge is shown. |
| Shipping-only offers | Excluded (`shipping_only_or_no_local_offer`). |
| Marketplace prices | Excluded unless the seller is Walmart.com (seller id `F55CDC31…`), checked on listing **and** product page. |
| Sponsored placements | Excluded (`sponsored_placement`); the organic copy is collected from its own position. |
| Duplicates | Primary key = Walmart item id across the whole run (pagination overlap, repeated category, sponsored copy). Counted as `duplicates_prevented`. |
| Approximate weight | Title and product size checked for approx / approximately / avg wt / ~ / weight varies → excluded. |
| PPM | Walmart's displayed unit price string copied verbatim (e.g. `17.4 ¢/oz`); empty when not shown; never computed. |
| UPC / GUPC | UPC from the product page, never altered. `gupc` always `""`. |
| unit_price | Always `""` (downstream pipeline). |
| Prices | `regular_price` = was-price when on sale, else current; `sale_price` = current when a was-price exists. Two-decimal strings. |
| Volume vs digital deals | `parse/deals.py`: clip / coupon / activate / add offer → digital; N for $X, BOGO, mix & match, must buy, buy N → volume. Wording preserved; price only when displayed; Walmart Cash / cashback / rebates never treated as price reductions. |
| Private label | `config/private_label_brands.txt` matched against brand and title start → `store_brand` = `yes` / `no`. |

## Silent-blocking and completeness detection

* Bot-challenge markers, block-page redirects, HTTP errors, tiny responses and abnormal latency are detected per request.
* Every parser validates the response **shape**; a changed or partial page raises `ShapeError` instead of returning 0 items.
* A listing that finishes with **zero** items fails validation – a block is never a legitimately empty category.
* Category counts are compared to the last successful run; a drop below `yield_drop_threshold` (60 %) blocks publication.
* Canary items are read at the start and end of the run; failure = run treated as blocked.
* Listings that hit Walmart's 25-page cap are flagged so they can be split further.

## Failed runs never replace good data

1. Every run writes only to `runs/<run_id>/`.
2. `latest/` is updated only after validation passes: stage → keep `previous-*` → swap → manifest (commit point).
3. Blob versioning + soft delete (14 days) give an extra rollback path.
4. An aborted production run keeps its checkpoint and `state.json` points to it; the next run **continues** it.

## Checkpointing

SQLite per run: listing table (next page, status), items table (record per item id), seen table (kept / skipped
reason), meta (store verification, canaries, runtime). Each page's records and the page pointer are written in **one
transaction**, so a crash can neither lose nor duplicate a page. In Azure the database is uploaded to Blob after every
committed page.
