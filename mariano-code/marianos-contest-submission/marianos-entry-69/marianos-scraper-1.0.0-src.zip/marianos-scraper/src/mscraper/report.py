"""Run report: everything the contest asks to see, generated from the checkpoint."""
from __future__ import annotations

import json
from collections import Counter

from . import deals
from .validate import completeness
from .version import version_info


def _examples(records, predicate, n=5):
    return [r for r in records if predicate(r)][:n]


def _offer_census(census: dict) -> dict:
    rows = []
    for text, e in sorted(census.items(), key=lambda kv: -kv[1]["count"]):
        rows.append({"label": text, "template": e.get("template", ""), "count": e["count"],
                     "classified_as": deals.kind_of(text, e.get("template", ""))})
    totals = Counter()
    for r in rows:
        totals[r["classified_as"]] += r["count"]
    return {"distinct_labels": len(rows), "occurrences_by_class": dict(totals), "labels": rows[:200]}


def build_report(run_id, location, ck, records, runtime_s, validation, settings, categories) -> dict:
    listings = ck.listings()
    reasons = ck.skip_reasons()
    by_cat = Counter(r["category"] for r in records)
    by_sub = Counter(f"{r['category']} > {r['sub_category']}" for r in records)
    upc_counts = Counter(r["upc"] for r in records)
    cat_cov = {}
    for c in categories:
        ls = [l for l in listings if l["category"] == c.name]
        cat_cov[c.name] = {
            "kind": c.kind, "csv_url": c.url, "discovery": ck.get(f"discovered:{c.name}"),
            "listings": len(ls), "listings_done": sum(l["status"] == "done" for l in ls),
            "listings_failed": sum(l["status"] == "failed" for l in ls),
            "pages_read": sum(l["pages"] for l in ls), "products_listed": sum(l["seen"] for l in ls),
            "products_in_subcategory": sum(l["matched"] for l in ls), "records_kept": by_cat.get(c.name, 0),
        }
        if c.kind == "coupons":
            cat_cov[c.name]["coupons_read"] = (ck.get("coupons") or {}).get("count", 0)
    return {
        "run_id": run_id,
        "scraper": version_info(),
        "location": {"key": location.key, "store_id": location.store_id, "zipcode": location.zipcode},
        "scope": ck.get("scope"),
        "started_at": ck.get("started_at"),
        "crawl_date": ck.get("crawl_date"),
        "store_verification": ck.get("store_verification"),
        "store_checks_during_run": {"pages_with_store_verified": ck.get("store_verified_pages", 0),
                                    "store_mismatches": ck.get("store_mismatches", 0)},
        "runtime_seconds": round(runtime_s, 1),
        "resumes": ck.get("resumes", 0),
        "total_unique_records": len(records),
        "duplicate_records_in_output": sum(n - 1 for n in upc_counts.values() if n > 1),
        "duplicates_prevented": reasons.get("duplicate", 0),
        "excluded": {k: v for k, v in reasons.items() if k not in ("kept", "duplicate")},
        "count_by_category": dict(sorted(by_cat.items())),
        "count_by_subcategory": dict(sorted(by_sub.items())),
        "category_coverage": cat_cov,
        "listings": listings,
        "field_completeness": completeness(records),
        "examples": {
            "ppm": _examples(records, lambda r: r["ppm"]),
            "sale_price": _examples(records, lambda r: r["sale_price"]),
            "volume_deals": _examples(records, lambda r: r["volume_deals_description"]),
            "digital_deals": _examples(records, lambda r: r["digital_deals_description"]),
            "no_deals": _examples(records, lambda r: not (r["sale_price"] or r["volume_deals_description"]
                                                         or r["digital_deals_description"])),
            "store_brand": _examples(records, lambda r: r["store_brand"] == "yes"),
        },
        "coupons": ck.get("coupons", {}),
        "offer_census": _offer_census(ck.get("offer_census", {})),
        "canary": ck.get("canary", {}),
        "fetch_stats": ck.get("fetch_stats", {}),
        "validation": validation,
        "events_tail": [{"ts": t, "kind": k, "detail": json.loads(d)} for t, k, d in ck.db.execute(
            "SELECT ts, kind, detail FROM events ORDER BY rowid DESC LIMIT 50").fetchall()],
    }
