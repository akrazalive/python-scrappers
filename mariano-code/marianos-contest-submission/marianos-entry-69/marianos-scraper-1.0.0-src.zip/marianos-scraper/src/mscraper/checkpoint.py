"""Durable run state in SQLite: genuine continuation after an interruption.

Stored per run:
* listings – every (category, shelf) with the next search page to fetch, status and stop reason
* items    – every accepted record (JSON) keyed by UPC → dedup across the whole run
* seen     – every UPC encountered with the reason it was kept or skipped
* meta     – store verification, canaries, discovery results, counters
* events   – structured audit trail (retries, mismatches, failures)

A page's records are written in the same transaction that advances that listing's page
pointer, so a crash can never lose a page or store it twice.
"""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS listings (
  category TEXT, sub_category TEXT, url TEXT, query TEXT, taxonomy TEXT, curated INTEGER DEFAULT 0,
  next_page INTEGER DEFAULT 1, status TEXT DEFAULT 'pending', error TEXT DEFAULT '',
  seen INTEGER DEFAULT 0, matched INTEGER DEFAULT 0, kept INTEGER DEFAULT 0, pages INTEGER DEFAULT 0,
  reported_total INTEGER DEFAULT 0, empty_streak INTEGER DEFAULT 0, stop_reason TEXT DEFAULT '',
  PRIMARY KEY (category, url));
CREATE TABLE IF NOT EXISTS items (upc TEXT PRIMARY KEY, category TEXT, sub_category TEXT, record TEXT);
CREATE TABLE IF NOT EXISTS seen (upc TEXT, category TEXT, sub_category TEXT, reason TEXT);
CREATE TABLE IF NOT EXISTS events (ts TEXT DEFAULT CURRENT_TIMESTAMP, kind TEXT, detail TEXT);
"""


class Checkpoint:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(self.path)
        self.db.executescript(SCHEMA)
        self.db.commit()

    @contextmanager
    def tx(self):
        try:
            yield self.db
            self.db.commit()
        except Exception:
            self.db.rollback()
            raise

    # meta / events
    def set(self, key: str, value) -> None:
        with self.tx() as db:
            db.execute("INSERT OR REPLACE INTO meta VALUES (?, ?)", (key, json.dumps(value)))

    def get(self, key: str, default=None):
        row = self.db.execute("SELECT v FROM meta WHERE k=?", (key,)).fetchone()
        return json.loads(row[0]) if row else default

    def incr(self, key: str, by: int = 1) -> int:
        v = int(self.get(key, 0)) + by
        self.set(key, v)
        return v

    def event(self, kind: str, detail: dict) -> None:
        with self.tx() as db:
            db.execute("INSERT INTO events(kind, detail) VALUES (?, ?)", (kind, json.dumps(detail, default=str)))

    # listings
    def add_listing(self, category: str, sub: str, url: str, query: str, taxonomy: str, curated: bool) -> None:
        with self.tx() as db:
            db.execute("INSERT OR IGNORE INTO listings(category, sub_category, url, query, taxonomy, curated) VALUES (?,?,?,?,?,?)",
                       (category, sub, url, query, taxonomy, int(curated)))

    def listings(self) -> list[dict]:
        cur = self.db.execute("SELECT * FROM listings ORDER BY rowid")
        cols = [c[0] for c in cur.description]
        return [dict(zip(cols, r)) for r in cur.fetchall()]

    def pending(self) -> list[dict]:
        return [l for l in self.listings() if l["status"] in ("pending", "running")]

    def commit_page(self, category: str, url: str, page: int, accepted: list[tuple[str, str, dict]],
                    skipped: list[tuple[str, str]], seen: int, matched: int, done: bool, stop_reason: str,
                    empty_streak: int, reported_total: int) -> int:
        """Atomically store a page's records and advance the listing pointer. Returns # newly kept."""
        new = 0
        with self.tx() as db:
            for upc, sub, rec in accepted:
                cur = db.execute("INSERT OR IGNORE INTO items VALUES (?,?,?,?)", (upc, category, sub, json.dumps(rec)))
                if cur.rowcount:
                    new += 1
                db.execute("INSERT INTO seen VALUES (?,?,?,?)", (upc, category, sub, "kept" if cur.rowcount else "duplicate"))
            for upc, reason in skipped:
                db.execute("INSERT INTO seen VALUES (?,?,?,?)", (upc, category, "", reason))
            db.execute("UPDATE listings SET next_page=?, status=?, seen=seen+?, matched=matched+?, kept=kept+?, pages=pages+1, "
                       "empty_streak=?, stop_reason=?, reported_total=MAX(reported_total, ?) WHERE category=? AND url=?",
                       (page + 1, "done" if done else "running", seen, matched, new, empty_streak, stop_reason,
                        reported_total, category, url))
        return new

    def finish_listing(self, category: str, url: str, stop_reason: str) -> None:
        with self.tx() as db:
            db.execute("UPDATE listings SET status='done', stop_reason=? WHERE category=? AND url=?", (stop_reason, category, url))

    def fail_listing(self, category: str, url: str, error: str) -> None:
        with self.tx() as db:
            db.execute("UPDATE listings SET status='failed', error=? WHERE category=? AND url=?", (error[:500], category, url))

    def retry_failed(self) -> int:
        with self.tx() as db:
            return db.execute("UPDATE listings SET status='pending', error='' WHERE status='failed'").rowcount

    # items
    def kept_in_category(self, category: str) -> int:
        return self.db.execute("SELECT COUNT(*) FROM items WHERE category=?", (category,)).fetchone()[0]

    def records(self) -> list[dict]:
        return [json.loads(r[0]) for r in self.db.execute("SELECT record FROM items ORDER BY rowid")]

    def skip_reasons(self) -> dict[str, int]:
        return dict(self.db.execute("SELECT reason, COUNT(*) FROM seen GROUP BY reason").fetchall())

    def close(self) -> None:
        self.db.close()
