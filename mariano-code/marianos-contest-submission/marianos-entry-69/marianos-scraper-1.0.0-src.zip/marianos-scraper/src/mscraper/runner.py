"""One run for one store location: verify store → discover → crawl → coupons → validate → publish.

Every step is checkpointed; `run --resume` continues an interrupted run from the exact
listing page where it stopped (records already stored are never fetched or written twice).
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote, urlencode, urlparse, parse_qsl

from . import parse
from .checkpoint import Checkpoint
from .config import Category, Location, Settings
from .fetch import FetchError, build_fetcher
from .report import build_report
from .validate import validate_run

log = logging.getLogger("mscraper.run")


def _with_page(url: str, page: int) -> str:
    if page <= 1:
        return url
    p = urlparse(url)
    q = [(k, v) for k, v in parse_qsl(p.query, keep_blank_values=True) if k != "page"] + [("page", str(page))]
    return p._replace(query=urlencode(q)).geturl()


class Runner:
    def __init__(self, settings: Settings, location: Location, storage, state_dir: Path, run_id: str | None = None,
                 categories: list[str] | None = None, limit_per_category: int = 0, fetcher=None):
        self.s, self.loc, self.storage = settings, location, storage
        self.cats: list[Category] = settings.categories_for(location, categories)
        self.scoped = bool(categories or location.categories)
        self.limit = int(limit_per_category or location.limit_per_category or 0)
        self.base = settings.get("base_url", "https://www.marianos.com").rstrip("/")
        self.run_id = run_id or datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ-") + uuid.uuid4().hex[:6]
        self.dir = Path(state_dir) / location.key / "runs" / self.run_id
        self.dir.mkdir(parents=True, exist_ok=True)
        self.ck = Checkpoint(self.dir / "checkpoint.sqlite")
        self.fetcher = fetcher or build_fetcher(settings, location)
        self.census: dict[str, dict] = self.ck.get("offer_census", {})
        self.page_size = int(settings.get("crawl.page_size", 24))
        self.max_pages = int(settings.get("crawl.max_pages_per_query", 42))
        self.empty_stop = int(settings.get("crawl.stop_after_empty_pages", 3))
        self.skip_shelves = [re.compile(p, re.I) for p in settings.get("crawl.skip_shelf_patterns") or []]

    # ------------------------------------------------------------------ helpers
    def _ctx(self, category: str, sub: str) -> dict:
        st = self.ck.get("store_verification") or {}
        return {"store_id": self.loc.store_id, "zipcode": st.get("zipcode", ""), "store_name": st.get("store_name", ""),
                "store_location": st.get("store_location", ""), "store_logo": st.get("store_logo", ""),
                "brands": self.s.private_label_brands, "category": category, "sub_category": sub, "base_url": self.base,
                "crawl_date": self.ck.get("crawl_date"), "exclude_sold_by_weight": self.s.get("crawl.exclude_sold_by_weight", True)}

    async def _search(self, url: str) -> tuple[parse.SearchPage, str]:
        box = {}

        def check(html: str):
            box["sp"] = parse.search_page(parse.extract_state(html))

        res = await self.fetcher.get(url, validate=check)
        return box["sp"], res.html

    def _store_ok(self, store: parse.StoreInfo, where: str) -> bool:
        if store.location_id == self.loc.store_id:
            self.ck.incr("store_verified_pages")
            return True
        self.ck.incr("store_mismatches")
        self.ck.event("store_mismatch", {"where": where, "got": store.location_id, "name": store.name, "want": self.loc.store_id})
        log.error("store mismatch", extra={"where": where, "got": store.location_id, "want": self.loc.store_id})
        return False

    # ------------------------------------------------------------------ 1. store + canary
    async def verify_store(self) -> dict:
        q = self.loc.canary_query or "milk"
        sp, html = await self._search(f"{self.base}/search?query={quote(q)}&searchType=default_search")
        st = sp.store
        checks = {
            "location_id_matches": st.location_id == self.loc.store_id,
            "search_request_pinned_to_store": sp.request_location == self.loc.store_id,
            "zipcode_matches": (not self.loc.zipcode) or st.zipcode == self.loc.zipcode,
            "address_matches": (not self.loc.expected_address) or self.loc.expected_address.lower() in st.full_address.lower(),
            "prices_from_store": all(((sp.products.get(u, {}).get("data") or {}).get("price") or {}).get("storePrices", {})
                                     .get("sourceLocationId") == self.loc.store_id for u in sp.upcs if u in sp.products),
        }
        result = {"verified": all(checks.values()), "checks": checks, "configured_store_id": self.loc.store_id,
                  "selected_store_id": st.location_id, "store_name": st.name, "store_location": st.full_address,
                  "zipcode": st.zipcode, "banner": st.banner,
                  "store_logo": parse.store_logo(html, self.base) or self.s.get("store_logo_fallback", ""),
                  "verified_at": datetime.now(timezone.utc).isoformat(timespec="seconds"), "evidence_query": q}
        self.ck.set("store_verification", result)
        (self.dir / "evidence").mkdir(exist_ok=True)
        (self.dir / "evidence" / "store_page_state_excerpt.json").write_text(json.dumps(
            {"modalityPreferences": "storeDetails / modalities as served by marianos.com", "store": st.__dict__,
             "search_request_location": sp.request_location}, indent=2), encoding="utf-8")
        log.info("store verification", extra=result)
        return result

    async def canary(self, phase: str) -> dict:
        q = self.loc.canary_query or "milk"
        found, priced, pages = set(), 0, 0
        try:
            for page in (1, 2):
                sp, _ = await self._search(_with_page(f"{self.base}/search?query={quote(q)}&searchType=default_search", page))
                pages += 1
                self._store_ok(sp.store, f"canary-{phase}")
                for u in sp.upcs:
                    sprice = ((sp.products.get(u, {}).get("data") or {}).get("price") or {}).get("storePrices") or {}
                    if sprice.get("regular") and sprice.get("sourceLocationId") == self.loc.store_id:
                        priced += 1
                        found.add(u)
                if all(u in found for u in self.loc.canary_upcs):
                    break
            missing = [u for u in self.loc.canary_upcs if u not in found]
            ok = priced >= self.page_size // 2 and not missing
            res = {"ok": ok, "priced_products": priced, "pages": pages, "missing_canary_upcs": missing,
                   "detail": "" if ok else f"priced={priced}, missing={missing}"}
        except FetchError as exc:
            res = {"ok": False, "detail": f"fetch failed: {exc}"}
        c = self.ck.get("canary", {})
        c[phase] = res
        self.ck.set("canary", c)
        return res

    # ------------------------------------------------------------------ 2. discovery
    async def _site_menu(self) -> dict:
        """The site menu (every department with its sub-category links) is embedded in every Mariano's page;
        it is read once per run from a store-verified search page and kept in the checkpoint."""
        menu = self.ck.get("site_menu")
        if not menu:
            box = {}

            def check(html):
                st = parse.extract_state(html)
                m = {k: v for k, v in (st.get("dynamicdata") or {}).items() if "site-menu" in k}
                if not m:
                    raise parse.PageError("site menu missing", "malformed")
                box["m"], box["store"] = m, parse.store_info(st)

            await self.fetcher.get(f"{self.base}/search?query={quote(self.loc.canary_query or 'milk')}&searchType=default_search",
                                   validate=check)
            self._store_ok(box["store"], "site menu page")
            menu = box["m"]
            self.ck.set("site_menu", menu)
        return {"dynamicdata": menu}

    async def discover(self, cat: Category) -> None:
        key = f"discovered:{cat.name}"
        if self.ck.get(key):
            return
        if cat.kind == "coupons":
            self.ck.set(key, {"kind": "coupons"})
            return
        if cat.kind == "list":
            sh = parse.shelf_from_url(cat.name, urlparse(cat.url).path)
            for q in sh.queries():
                self.ck.add_listing(cat.name, cat.name, f"{self.base}/search?query={quote(q)}&searchType=default_search",
                                    q, cat.taxonomy_id, False)
            self.ck.set(key, {"kind": "list", "shelves": 1, "taxonomy": cat.taxonomy_id, "queries": sh.queries()})
            return
        menu_state = await self._site_menu()
        shelves = parse.department_shelves(menu_state, cat.slug)          # complete sub-category tree from the site menu
        box = {}

        def check(html):
            box["state"] = parse.extract_state(html)

        try:  # the department page adds its curated tiles; it is optional because the menu already lists every shelf
            await self.fetcher.get(cat.url, validate=check, retries=int(self.s.get("crawl.department_page_retries", 2)))
            self._store_ok(parse.store_info(box["state"]), f"department {cat.name}")
            known = {(x.taxonomy or x.query.lower()) for x in shelves}
            for x in parse.department_shelves(box["state"], cat.slug):
                if (x.taxonomy or x.query.lower()) not in known:
                    shelves.append(x)
        except FetchError as exc:
            self.ck.event("department_page_unavailable", {"category": cat.name, "url": cat.url, "error": str(exc)[:200],
                                                         "used": "site menu sub-categories"})
        dept = parse.department_code(shelves)
        kept, skipped = 0, []
        for sh in shelves:
            if any(rx.search(sh.name) for rx in self.skip_shelves):
                skipped.append(sh.name)
                continue
            if sh.curated and not self.s.get("crawl.include_curated_shelves", True):
                skipped.append(sh.name)
                continue
            urls = []
            if sh.curated:  # the shelf's own curated search first, then its name
                urls.append((self.base + sh.url if sh.url.startswith("/") else sh.url, sh.query))
                tax = dept if self.s.get("crawl.curated_department_filter", True) else ""
            else:
                tax = sh.taxonomy
            for q in sh.queries():
                urls.append((f"{self.base}/search?query={quote(q)}&searchType=default_search", q))
            for url, q in urls:
                self.ck.add_listing(cat.name, sh.name, url, q, tax, sh.curated)
            kept += 1
        if not kept:
            self.ck.event("discovery_failed", {"category": cat.name, "url": cat.url})
            raise FetchError(f"no sub-categories found on {cat.url}", "malformed")
        self.ck.set(key, {"kind": "department", "shelves": kept, "skipped_brand_shelves": skipped, "department_code": dept,
                          "subcategories": [s.name for s in shelves if s.name not in skipped]})

    # ------------------------------------------------------------------ 3. crawl one listing
    async def crawl_listing(self, l: dict) -> None:
        """Read one search query of a shelf. Mariano's server-rendered search returns the first 24 results of a
        query whatever page is asked for, so coverage comes from query expansion: every query that adds new
        products of the shelf queues new queries built from those products (their sub-commodity names and
        brand + shelf name). A shelf saturates when its queries stop adding products or its query cap is hit."""
        cat, url, sub = l["category"], l["url"], l["sub_category"]
        page, streak = int(l["next_page"]), int(l["empty_streak"])
        paginate = bool(self.s.get("crawl.paginate", False))
        seen_here: set[str] = set()
        while True:
            if self.limit and self.ck.kept_in_category(cat) >= self.limit:
                self.ck.finish_listing(cat, url, "demo_limit_reached")
                return
            try:
                sp, _ = await self._search(_with_page(url, page))
            except FetchError as exc:
                self.ck.fail_listing(cat, url, f"page {page}: {exc}")
                self.ck.event("listing_failed", {"category": cat, "sub": sub, "query": l["query"], "error": str(exc)})
                return
            if not self._store_ok(sp.store, f"{cat} / {sub} [{l['query']}]") or (
                    sp.request_location and sp.request_location != self.loc.store_id):
                self.ck.fail_listing(cat, url, f"page {page}: store context mismatch")
                return
            accepted, skipped, matched, terms = [], [], 0, []
            ctx = self._ctx(cat, sub)
            for upc in sp.upcs:
                prod = sp.products.get(upc)
                if not parse.matches(parse.product_codes(prod, sp.codes.get(upc)), l["taxonomy"]):
                    skipped.append((upc, "outside_subcategory"))
                    continue
                matched += 1
                if not prod or "data" not in prod:
                    skipped.append((upc, "no_product_data"))
                    continue
                m = parse.map_product(prod, ctx)
                if m.reason == "store_mismatch":
                    self.ck.incr("store_mismatches")
                    self.ck.event("store_mismatch", {"upc": upc, "source": m.source_location})
                for text, tpl in m.offer_labels:
                    e = self.census.setdefault(text, {"count": 0, "template": tpl})
                    e["count"] += 1
                if m.record:
                    accepted.append((upc, sub, m.record))
                else:
                    skipped.append((upc, m.reason))
                terms.extend(parse.expansion_terms(prod, l["taxonomy"], sub))
            streak = 0 if matched else streak + 1
            new_upcs = [u for u in sp.upcs if u not in seen_here]
            seen_here.update(sp.upcs)
            done, reason = True, "single_page_query"
            if paginate:
                done, reason = False, ""
                if len(sp.upcs) < self.page_size or (sp.total and page * self.page_size >= sp.total):
                    done, reason = True, "end_of_results"
                elif not new_upcs:
                    done, reason = True, "page_repeats_previous_results"
                elif streak >= self.empty_stop:
                    done, reason = True, f"no_matching_products_in_{self.empty_stop}_pages"
                elif page >= self.max_pages:
                    done, reason = True, "query_page_window_reached"
            new = self.ck.commit_page(cat, url, page, accepted, skipped, len(sp.upcs), matched, done, reason, streak, sp.total)
            queued = self._expand(l, terms) if new else 0
            log.info("query", extra={"category": cat, "sub": sub, "query": l["query"], "listed": len(sp.upcs),
                                     "matched": matched, "new_records": new, "queued_queries": queued,
                                     "reported_total": sp.total})
            if done:
                return
            page += 1

    def _expand(self, l: dict, terms: list[str]) -> int:
        cap = int(self.s.get("crawl.max_queries_per_shelf", 40))
        shelf = [x for x in self.ck.listings() if x["category"] == l["category"] and x["sub_category"] == l["sub_category"]]
        used = {x["query"].lower() for x in shelf}
        added = 0
        for t in terms:
            if len(shelf) + added >= cap:
                break
            if t.lower() in used:
                continue
            used.add(t.lower())
            self.ck.add_listing(l["category"], l["sub_category"],
                                f"{self.base}/search?query={quote(t)}&searchType=default_search",
                                t, l["taxonomy"], bool(l["curated"]))
            added += 1
        return added

    # ------------------------------------------------------------------ 4. coupons
    async def collect_coupons(self, cat: Category) -> None:
        if self.ck.get("coupons_done"):
            return
        box = {}

        def check(html):
            box["coupons"] = parse.coupons(html)
            box["store"] = parse.store_info(parse.extract_state(html))

        res = await self.fetcher.get(cat.url, render_js=bool(self.s.get("coupons.render_js", True)), validate=check)
        self._store_ok(box["store"], "coupons page")
        cps = box["coupons"]
        (self.dir / "coupons.json").write_text(json.dumps(cps, indent=2, ensure_ascii=False), encoding="utf-8")
        self.ck.set("coupons", {"count": len(cps), "url": cat.url, "bytes": len(res.html)})
        self.ck.set("coupons_done", True)

    # ------------------------------------------------------------------ main
    async def run(self, publish: bool = True) -> dict:
        t0 = time.monotonic()
        started = self.ck.get("started_at")
        if not started:
            self.ck.set("started_at", datetime.now(timezone.utc).isoformat(timespec="seconds"))
            self.ck.set("crawl_date", datetime.now(timezone.utc).date().isoformat())
            self.ck.set("scope", {"categories": [c.name for c in self.cats], "limit_per_category": self.limit,
                                  "scoped_demo": self.scoped or bool(self.limit)})
        else:
            self.ck.incr("resumes")
            self.ck.event("resumed", {"retried_failed_listings": self.ck.retry_failed()})
        await self.fetcher.start()
        try:
            store = self.ck.get("store_verification") or {}
            if not store.get("verified"):
                store = await self.verify_store()
                if not store["verified"]:
                    raise RuntimeError(f"store verification failed: {store['checks']}")
            if not (self.ck.get("canary") or {}).get("start"):
                await self.canary("start")
            for cat in self.cats:
                try:
                    await self.discover(cat)
                    if self.ck.get(f"discovery_error:{cat.name}"):
                        self.ck.set(f"discovery_error:{cat.name}", None)   # earlier failure healed on resume
                except FetchError as exc:
                    self.ck.set(f"discovery_error:{cat.name}", str(exc))
                    log.error("discovery failed", extra={"category": cat.name, "error": str(exc)})
            for wave in range(int(self.s.get("crawl.max_expansion_waves", 30))):
                pending = self.ck.pending()
                if not pending:
                    break
                log.info("crawl", extra={"wave": wave + 1, "queries_pending": len(pending),
                                         "queries_total": len(self.ck.listings())})
                await asyncio.gather(*(self.crawl_listing(l) for l in pending))
            self.ck.set("offer_census", self.census)
            for cat in self.cats:
                if cat.kind == "coupons" and self.s.get("coupons.enabled", True):
                    try:
                        await self.collect_coupons(cat)
                    except FetchError as exc:
                        self.ck.set("coupons_error", str(exc))
            await self.canary("end")
        finally:
            self.ck.set("offer_census", self.census)
            self.ck.set("fetch_stats", {**self.fetcher.stats, "provider": self.fetcher.name})
            await self.fetcher.close()
        runtime = time.monotonic() - t0 + float(self.ck.get("runtime_before_resume", 0))
        self.ck.set("runtime_before_resume", runtime)
        return self.finish(runtime, publish)

    def finish(self, runtime: float, publish: bool) -> dict:
        records = self.ck.records()
        prev = self.storage.get_json(f"{self.loc.key}/latest/report.json")
        v = validate_run(self.s, self.ck, records, self.cats, prev)
        demo = (self.ck.get("scope") or {}).get("scoped_demo")
        if demo:
            v.warn("demo scope (category subset / per-category limit): never published to latest/")
        report = build_report(self.run_id, self.loc, self.ck, records, runtime, v.as_dict(), self.s, self.cats)
        body = json.dumps(records, ensure_ascii=False, indent=2)
        (self.dir / "records.json").write_text(body, encoding="utf-8")
        (self.dir / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        base = f"{self.loc.key}/runs/{self.run_id}"
        self.storage.put_bytes(f"{base}/records.json", body.encode("utf-8"))
        self.storage.put_json(f"{base}/report.json", report)
        cp = self.dir / "coupons.json"
        if cp.exists():
            self.storage.put_bytes(f"{base}/coupons.json", cp.read_bytes())
        status = "validation_failed"
        if v.ok and not demo and publish:
            self.storage.publish(self.loc.key, self.run_id, records, report)
            status = "published"
        elif v.ok:
            status = "valid_not_published_demo" if demo else "valid_not_published"
        self.ck.set("final_status", status)
        log.info("run finished", extra={"status": status, "records": len(records), "errors": v.errors[:10]})
        return {"run_id": self.run_id, "status": status, "records": len(records), "dir": str(self.dir),
                "errors": v.errors, "warnings": v.warnings}
