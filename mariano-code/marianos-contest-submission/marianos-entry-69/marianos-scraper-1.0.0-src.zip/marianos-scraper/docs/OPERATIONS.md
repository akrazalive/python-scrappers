# Operations

## 1. Install in Azure (one command)

Prerequisites: Azure CLI logged in (`az login`), Bicep (bundled with recent Azure CLI), Python 3.11+.

```bash
export OXYLABS_WEBAPI_KEY=...                       # stored in Key Vault by the template
./deploy/azure/deploy.sh rg-marianos-scraper eastus
```

Creates in the resource group:

| Resource | Purpose |
|---|---|
| Container Apps Job `mscraper-job` | scheduled run, cron `0 7 * * 2,5` (Tue + Fri 07:00 UTC), 8 h timeout |
| Storage account – Blob container `marianos-scraper` | releases, published output, run history, run locks (blob lease) |
| Storage account – Azure Files share `scraper-state` | checkpoints mounted at `/state` → interrupted runs resume |
| Key Vault | `oxylabs-webapi-key` |
| User-assigned managed identity | Blob Data Contributor on the storage account, Key Vault Secrets User on the vault |
| Log Analytics workspace | JSON logs from every run |

Change the schedule: redeploy with `-p cronExpression='0 5 * * 1,4'` or edit the job in the portal.

Run on demand: `az containerapp job start -g <rg> -n mscraper-job`

## 2. What a scheduled run does

For every `enabled: true` store in `config/locations.yaml`:
1. takes a blob lease `<location>/.run.lock` – a second overlapping run exits immediately
2. resumes the latest unfinished run from its checkpoint, or starts a new one
3. verifies the store (id, ZIP, address, every price's source store), runs the canary
4. discovers sub-categories from each CSV department page, crawls every shelf, reads the Coupons page
5. runs the canary again, validates the whole run, writes `runs/<run_id>/…`
6. publishes to `latest/` **only if validation passed**; otherwise `latest/` keeps the last good dataset

## 3. Monitoring

Log Analytics → `ContainerAppConsoleLogs_CL | where ContainerJobName_s == "mscraper-job"`.
Every line is JSON: store, category, sub-category, page, products listed / matched / kept, retries, errors, final status.

Useful queries:
* final status: `| where Log_s has "run finished"`
* store problems: `| where Log_s has "store mismatch"`
* retries: `| where Log_s has "retry"`

`runs/<run_id>/report.json` contains the validation result, counts per category and sub-category, completeness,
exclusions, store checks, canary results, request statistics and the last 50 audit events.

## 4. Recovery

| Situation | What happens / what to do |
|---|---|
| container killed / timeout / VM restart | next execution resumes the same run from the last committed page (no duplicates, no lost pages) |
| provider or Mariano's temporarily failing | each page is retried 4× with backoff; a shelf that still fails marks the run invalid → not published; the next run retries only failed shelves |
| store context changed / mismatch | run fails validation, nothing published; check `config/locations.yaml` `store_id` and run `verify-store` |
| bad data published by mistake | copy `latest/previous-records.json` → `latest/records.json` (one-step rollback); blob versioning keeps 14 days |
| need to restart from scratch | run without `--resume` (new run id) |

## 5. Add a store

1. find the store id (division 531 + 5-digit store number), e.g. from marianos.com/stores
2. add an entry to `config/locations.yaml` with `key`, `store_id`, `zipcode`, `expected_address`, canary UPCs
3. `python -m mscraper verify-store --location <key>` – must print `"verified": true`
4. upload the new package (`deploy.sh` again) – no code changes

## 6. Add or change categories

Edit `config/categories.csv` (same columns as the contest file). Department URLs (`/d/<slug>`) are expanded into
their sub-categories automatically; product-list URLs (`/pl/<slug>/<id>`) are crawled as one sub-category;
the coupons URL is read as the Coupons category. Brand/merchandising shelves to skip are regexes in
`config/settings.yaml` → `crawl.skip_shelf_patterns`.

## 7. Maintenance

* `python -m pytest -q` before every release (runs offline on saved real responses)
* if Mariano's changes its page format, the run fails validation (it never publishes partial data) and
  `tests/test_rules.py` shows which field moved; parsing lives in one module: `src/mscraper/parse.py`
* rotate the provider key: update the Key Vault secret `oxylabs-webapi-key`; no redeploy needed
