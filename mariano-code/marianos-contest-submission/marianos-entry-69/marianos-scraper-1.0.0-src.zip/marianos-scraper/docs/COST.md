# Monthly Operating Cost (one store, twice weekly)

## Paid services (complete list)

1. **Oxylabs Web Scraper API** (Kroger endpoint) – the only paid data-access service. One request = one Mariano's page.
   Faulted requests are not charged (stated in Oxylabs' own error responses: *"we don't charge you for faulted scrapes"*).
2. **Standard Azure resources** in your subscription (table below).

No other proxies, APIs, SaaS tools or licences are used.

## Measured request volumes (live runs, store 53100544, 21 Oct 2026)

| Run | Scope | Requests | Records | Notes |
|---|---|---|---|---|
| 20261021T042105Z-fa0c1b | Dairy, Coffee, Breakfast, Batteries, Light Bulbs, Coupons | 131 (114 ok, 16 retries) | 1,027 | first-page reads per shelf, one resume |
| 20261021T044142Z-cf40b8 | same, with query expansion | 85 seed queries (wave 1) | 950 | stopped by the trial plan's quota during wave 2 |

## Estimate for a full store run

* CSV: 23 department rows (~10 sub-categories each) + 4 product-list rows + Coupons ≈ **235 shelves**
* query expansion: 1 request per query, capped at `crawl.max_queries_per_shelf` (40); shelves saturate earlier –
  planning figure **15–25 queries per shelf** → **3,500–6,000 requests per run** (+ ~5 % retries, not charged when faulted)
* twice weekly ≈ **8.7 runs / month** → **30,000–52,000 requests / month per store**

| Item | Basis | Estimate / month |
|---|---|---|
| Oxylabs Web Scraper API | 30k–52k requests × your plan's price per 1,000 (e.g. $1.00–$2.00 / 1k) | **≈ $30 – $105** |
| Azure Container Apps Job | ~1–2 h × 0.5 vCPU / 1 GiB × 9 runs (consumption plan; monthly free grant usually covers it) | $0 – $5 |
| Azure Blob Storage + Azure Files | < 2 GB incl. 14-day versions and checkpoints | ~$1 |
| Key Vault | a few hundred secret reads | < $1 |
| Log Analytics | < 1 GB ingestion | $0 – $3 |
| **Total (one store)** | | **≈ $32 – $115** |

Please confirm the per-1,000 price against your Oxylabs plan; the request counts above come from the run reports
(`fetch_stats.requests`) and every run reports its own number, so the bill can be checked run by run.

## Cost levers

* `crawl.max_queries_per_shelf` – lower = cheaper, higher = more coverage on very large shelves
* `fetch.max_requests_per_run` – hard safety cap per run (0 = unlimited)
* each additional store adds roughly the same provider cost again
