#!/usr/bin/env bash
# One-command deployment into an existing Azure subscription. No Docker build or registry needed:
# the scheduled job runs the versioned source package stored in Blob Storage.
#   export OXYLABS_WEBAPI_KEY=...            # stored in Key Vault, never in code
#   ./deploy/azure/deploy.sh <resource-group> <region>
set -euo pipefail
RG=${1:?resource group}; REGION=${2:?region e.g. eastus}
HERE="$(cd "$(dirname "$0")" && pwd)"; ROOT="$HERE/../.."
: "${OXYLABS_WEBAPI_KEY:?export OXYLABS_WEBAPI_KEY first}"

echo "1/4 source package (versioned ZIP + fingerprint)"
python "$ROOT/tools/package_source.py"
ZIP=$(ls "$ROOT"/dist/marianos-scraper-*-src.zip | tail -1); NAME=$(basename "$ZIP")

echo "2/4 infrastructure"
az group create -n "$RG" -l "$REGION" -o none
OUT=$(az deployment group create -g "$RG" -n mscraper-infra -f "$HERE/main.bicep" \
  -p oxylabsWebApiKey="$OXYLABS_WEBAPI_KEY" releaseBlob="releases/$NAME" --query properties.outputs -o json)
SA=$(echo "$OUT" | python -c "import json,sys;print(json.load(sys.stdin)['storageAccount']['value'])")
JOB=$(echo "$OUT" | python -c "import json,sys;print(json.load(sys.stdin)['jobName']['value'])")

echo "3/4 upload release package (the job runs exactly this file)"
ME=$(az ad signed-in-user show --query id -o tsv)
SCOPE=$(az storage account show -n "$SA" -g "$RG" --query id -o tsv)
az role assignment create --assignee-object-id "$ME" --assignee-principal-type User --role "Storage Blob Data Contributor" --scope "$SCOPE" -o none 2>/dev/null || true
az storage blob upload --account-name "$SA" -c marianos-scraper --auth-mode login -n "releases/$NAME" -f "$ZIP" --overwrite -o none

echo "4/4 done. Job $JOB runs Tue + Fri 07:00 UTC (twice weekly)."
echo "Run now:            az containerapp job start -g $RG -n $JOB"
echo "Execution history:  az containerapp job execution list -g $RG -n $JOB -o table"
echo "Published data:     container marianos-scraper / <location>/latest/records.json"
