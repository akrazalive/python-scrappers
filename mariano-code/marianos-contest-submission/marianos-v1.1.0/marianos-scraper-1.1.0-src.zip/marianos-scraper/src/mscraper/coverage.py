"""Machine-readable coverage / remaining-gap reconciliation (coverage.json).

What can be proven, and how:
* Mariano's reports, for every search request, how many products match it (`productsInfo.totalCount`), but its
  server-rendered search returns only the first 24 of them whatever page is requested.
* When a query reports more than it returned, the run partitions it with Mariano's own brand filter
  (`&brandName=<brand>`, the filter the site's own menu links use). Each brand slice is a separate request with its
  own reported total. A product has one brand, so the slices are disjoint.
* Seed requests (each shelf's own name and its parts) are the coverage universe; they are partitioned and
  reconciled. Expansion requests (built from discovered sub-commodity names and brands) add products and brands but
  are reported separately as supplementary, not counted in the proof.
* For every seed query the reconciliation compares the reported total with the number of DISTINCT products actually read
  for it (the query itself + all of its slices). `gap = reported_total - distinct_products_read`; gap 0 = proven
  complete for that query. Slices that themselves report more than they returned are listed with their own gap.

Limits that are reported, not hidden:
* Mariano's product-list pages (/pl/...) are not served to automated clients, so a sub-category's own total cannot be
  read; completeness is proven per search query, and every shelf lists the queries that cover it.
* Mariano's reports at most 1,000 for very broad requests; such totals are flagged `reported_total_is_capped` and can
  never count as complete – the shelf's narrower seed/brand requests carry the proof instead.
* A brand that never appeared in any page of the shelf cannot be sliced; it stays in that query's gap.
"""
from __future__ import annotations

from collections import defaultdict

REPORTED_TOTAL_CAP = 1000   # Mariano's search reports "1,000" for very broad requests (display cap)


def reconcile(listings: list[dict], listing_items: list[dict], kept_by_url: dict[str, int] | None = None) -> dict:
    items_by_url: dict[str, set] = defaultdict(set)
    for r in listing_items:
        items_by_url[r["url"]].add(r["upc"])
    by_parent: dict[str, list[dict]] = defaultdict(list)
    for l in listings:
        if l.get("parent"):
            by_parent[l["parent"]].append(l)

    queries, shelves, supplementary = [], {}, []
    for l in listings:
        if l.get("parent"):
            continue
        if (l.get("mode") or "query") == "coupon_filter":   # offer evidence, not coverage
            continue
        if (l.get("mode") or "query") == "expansion":   # discovery helpers: listed, not part of the proof
            supplementary.append({"category": l["category"], "sub_category": l["sub_category"], "query": l["query"],
                                  "status": l["status"], "reported_total": int(l.get("reported_total") or 0),
                                  "read": len(items_by_url.get(l["url"], ())), "new_records": int(l.get("kept") or 0)})
            continue
        slices = by_parent.get(l["url"], [])
        distinct = set(items_by_url.get(l["url"], set()))
        for s in slices:
            distinct |= items_by_url.get(s["url"], set())
        total = int(l.get("reported_total") or 0)
        capped = total >= REPORTED_TOTAL_CAP
        gap = max(0, total - len(distinct))
        q = {
            "category": l["category"], "sub_category": l["sub_category"], "query": l["query"], "url": l["url"],
            "status": l["status"], "reported_total": total, "listed_first_page": len(items_by_url.get(l["url"], ())),
            "brand_slices": len(slices), "brand_slice_reported_sum": sum(int(s.get("reported_total") or 0) for s in slices),
            "distinct_products_read": len(distinct), "gap": gap,
            "reported_total_is_capped": capped,   # Mariano's shows at most 1,000: the true total may be higher
            "complete": l["status"] == "done" and gap == 0 and not capped,
            "open_slices": [{"brand_filter": s["query"], "reported_total": int(s.get("reported_total") or 0),
                             "read": len(items_by_url.get(s["url"], ())), "status": s["status"]}
                            for s in slices if int(s.get("reported_total") or 0) > len(items_by_url.get(s["url"], ()))
                            or s["status"] != "done"],
        }
        queries.append(q)
        sh = shelves.setdefault((l["category"], l["sub_category"]), {"category": l["category"], "sub_category": l["sub_category"],
                                                                      "queries": 0, "queries_complete": 0, "gap_sum": 0,
                                                                      "failed": 0})
        sh["queries"] += 1
        sh["queries_complete"] += q["complete"]
        sh["gap_sum"] += gap
        sh["failed"] += l["status"] == "failed"
    cats: dict[str, dict] = {}
    for sh in shelves.values():
        c = cats.setdefault(sh["category"], {"shelves": 0, "shelves_all_queries_complete": 0, "queries": 0,
                                             "queries_complete": 0, "gap_sum": 0})
        c["shelves"] += 1
        c["shelves_all_queries_complete"] += sh["queries"] == sh["queries_complete"]
        c["queries"] += sh["queries"]
        c["queries_complete"] += sh["queries_complete"]
        c["gap_sum"] += sh["gap_sum"]
    return {
        "method": "per-query reconciliation: Mariano's reported totalCount vs distinct products read (query + brand slices)",
        "summary": {"queries": len(queries), "queries_complete": sum(q["complete"] for q in queries),
                    "queries_with_capped_total": sum(q["reported_total_is_capped"] for q in queries),
                    "products_in_gaps": sum(q["gap"] for q in queries)},
        "by_category": cats,
        "shelves": list(shelves.values()),
        "queries": queries,
        "expansion_requests": supplementary,
    }
