"""Command line.

  python -m mscraper verify-store --location <key>
  python -m mscraper run --location <key> [--categories "Dairy,Meat"] [--limit 100] [--resume] [--max-requests N]
  python -m mscraper run-all                       # every enabled location (used by the Azure scheduled job)
  python -m mscraper summary --location <key> [--run <run_id>]
  python -m mscraper probe --location <key> [--query Batteries]   # live paging / brand-filter probe with evidence
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
from pathlib import Path

from . import logging_setup
from .config import load_settings
from .lock import LockError, run_lock
from .runner import Runner
from .storage import build_storage


def _state_dir(settings) -> Path:
    d = Path(os.getenv("MSCRAPER_STATE_DIR") or settings.get("state_dir", "state"))
    return d if d.is_absolute() else Path(settings.get("_base_dir")) / d


def _latest_unfinished(state_dir: Path, key: str) -> str | None:
    import sqlite3

    runs = sorted((state_dir / key / "runs").glob("*/checkpoint.sqlite"), reverse=True)
    for ck in runs:
        db = sqlite3.connect(ck)
        try:
            row = db.execute("SELECT v FROM meta WHERE k='final_status'").fetchone()
        finally:
            db.close()
        if not row:
            return ck.parent.name
    return None


def cmd_run(args, settings, loc_key: str) -> dict:
    loc = settings.location(loc_key)
    storage = build_storage(settings)
    state = _state_dir(settings)
    run_id = args.run or (_latest_unfinished(state, loc.key) if args.resume else None)
    if args.max_requests:
        settings.raw.setdefault("fetch", {})["max_requests_per_run"] = args.max_requests
    cats = [c.strip() for c in args.categories.split(",")] if getattr(args, "categories", None) else None
    with run_lock(storage, loc.key):
        runner = Runner(settings, loc, storage, state, run_id=run_id, categories=cats, limit_per_category=args.limit or 0)
        logging_setup.setup(args.log_level, str(runner.dir / "run.log"))
        return asyncio.run(runner.run(publish=not args.no_publish))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="mscraper")
    ap.add_argument("--config", default=None)
    ap.add_argument("--log-level", default="INFO")
    sub = ap.add_subparsers(dest="cmd", required=True)
    v = sub.add_parser("verify-store")
    v.add_argument("--location", required=True)
    r = sub.add_parser("run")
    r.add_argument("--location", required=True)
    r.add_argument("--categories", default="")
    r.add_argument("--limit", type=int, default=0, help="max records per category (demo / smoke runs)")
    r.add_argument("--resume", action="store_true", help="continue the latest unfinished run")
    r.add_argument("--run", default=None, help="continue a specific run id")
    r.add_argument("--max-requests", type=int, default=0)
    r.add_argument("--no-publish", action="store_true")
    a = sub.add_parser("run-all")
    a.add_argument("--resume", action="store_true", default=True)
    pr = sub.add_parser("probe", help="~6-12 live requests: page 2 / JS paging / brand-filter behaviour, with evidence")
    pr.add_argument("--location", required=True)
    pr.add_argument("--query", default="Batteries")
    s = sub.add_parser("summary")
    s.add_argument("--location", required=True)
    s.add_argument("--run", default=None)
    args = ap.parse_args(argv)
    try:  # local runs: read .env; in Azure the values come from Key Vault-backed env vars
        from dotenv import load_dotenv

        load_dotenv()
    except ImportError:
        pass
    settings = load_settings(args.config)
    logging_setup.setup(args.log_level)

    if args.cmd == "verify-store":
        loc = settings.location(args.location)
        runner = Runner(settings, loc, build_storage(settings), _state_dir(settings) / "_verify")

        async def go():
            await runner.fetcher.start()
            try:
                return await runner.verify_store()
            finally:
                await runner.fetcher.close()

        res = asyncio.run(go())
        print(json.dumps(res, indent=2))
        return 0 if res["verified"] else 2

    if args.cmd == "probe":
        from datetime import datetime, timezone

        from .fetch import build_fetcher
        from .probe import run_probe

        loc = settings.location(args.location)
        out = _state_dir(settings) / loc.key / "probes" / datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        f = build_fetcher(settings, loc)

        async def go():
            await f.start()
            try:
                return await run_probe(f, settings, loc, out, args.query)
            finally:
                await f.close()

        rep = asyncio.run(go())
        print(json.dumps({"dir": str(out), "findings": rep["findings"], "requests": rep["fetch_stats"]}, indent=2))
        return 0

    if args.cmd == "run":
        try:
            res = cmd_run(args, settings, args.location)
        except LockError as exc:
            print(f"skipped: {exc}", file=sys.stderr)
            return 3
        print(json.dumps(res, indent=2))
        return 0 if res["status"] in ("published", "valid_not_published_demo", "valid_not_published") else 1

    if args.cmd == "run-all":
        rc = 0
        for loc in settings.locations:
            if not loc.enabled:
                continue
            ns = argparse.Namespace(run=None, resume=True, max_requests=0, categories="", limit=0, no_publish=False,
                                    log_level=args.log_level)
            try:
                res = cmd_run(ns, settings, loc.key)
                print(json.dumps(res))
                rc |= 0 if res["status"] == "published" else 1
            except LockError as exc:
                print(f"{loc.key}: skipped: {exc}", file=sys.stderr)
        return rc

    if args.cmd == "summary":
        state = _state_dir(settings) / args.location / "runs"
        run = args.run or sorted(p.name for p in state.iterdir() if p.is_dir())[-1]
        rep = json.loads((state / run / "report.json").read_text(encoding="utf-8"))
        keys = ("run_id", "runtime_seconds", "total_unique_records", "duplicate_records_in_output", "count_by_category",
                "excluded", "store_checks_during_run", "validation")
        print(json.dumps({k: rep.get(k) for k in keys}, indent=2))
        return 0
    return 1
