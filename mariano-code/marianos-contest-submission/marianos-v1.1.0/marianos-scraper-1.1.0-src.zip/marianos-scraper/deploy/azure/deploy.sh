#!/usr/bin/env bash
# Deploys the Mariano's scraper into an EXISTING resource group (no subscription-level rights needed).
#
#   ./deploy/azure/deploy.sh <subscription-id> <resource-group> infra     # phase 1: storage, Key Vault, identity, env
#   ./deploy/azure/deploy.sh <subscription-id> <resource-group> job       # phase 2: scheduled job (Tue+Fri 07:00 UTC)
#
# Options (environment variables):
#   ASSIGN_ROLES=true      deployer may assign roles (Owner / User Access Administrator / RBAC Administrator)
#   OXYLABS_WEBAPI_KEY=..  store the key in Key Vault during phase 1 (otherwise the client stores it, see below)
#   TAGS='{"owner":"x"}'   tags required by policy
#   CRON='0 7 * * 2,5'     schedule (UTC)
# Without role-assignment rights, phase 1 writes admin-role-commands.sh for the client's administrator.
set -euo pipefail
SUB=${1:?subscription id}; RG=${2:?existing resource group}; PHASE=${3:?infra|job}
HERE="$(cd "$(dirname "$0")" && pwd)"; ROOT="$HERE/../.."
ASSIGN_ROLES=${ASSIGN_ROLES:-false}; CRON=${CRON:-0 7 * * 2,5}
TAGS=${TAGS:-}
if [ -z "$TAGS" ]; then TAGS='{}'; fi
az account set --subscription "$SUB"
az group show -n "$RG" -o none            # must exist; this script never creates resource groups
OUTDIR="$ROOT/evidence/azure-deploy-$(date -u +%Y%m%dT%H%M%SZ)"; mkdir -p "$OUTDIR"

python "$ROOT/tools/package_source.py" | tee "$OUTDIR/package.txt"
ZIP=$(ls "$ROOT"/dist/marianos-scraper-*-src.zip | tail -1); NAME=$(basename "$ZIP")
DEPLOY_JOB=false; [ "$PHASE" = "job" ] && DEPLOY_JOB=true

OUT=$(az deployment group create -g "$RG" -n "mscraper-$PHASE" -f "$HERE/main.bicep" \
  -p assignRoles="$ASSIGN_ROLES" deployJob="$DEPLOY_JOB" releaseBlob="releases/$NAME" tags="$TAGS" \
     cronExpression="$CRON" oxylabsWebApiKey="${OXYLABS_WEBAPI_KEY:-}" \
  --query properties.outputs -o json)
echo "$OUT" > "$OUTDIR/deployment-outputs.json"
get(){ echo "$OUT" | python -c "import json,sys;print(json.load(sys.stdin)['$1']['value'])"; }
SA=$(get storageAccount); KV=$(get keyVault); PID=$(get identityPrincipalId); SID=$(get storageId); KID=$(get keyVaultId)

# upload the exact release the job runs (account key via Contributor; no data-plane role needed)
KEY=$(az storage account keys list -g "$RG" -n "$SA" --query "[0].value" -o tsv)
az storage blob upload --account-name "$SA" --account-key "$KEY" -c marianos-scraper -n "releases/$NAME" -f "$ZIP" --overwrite -o none
echo "uploaded releases/$NAME" | tee -a "$OUTDIR/package.txt"

if [ "$PHASE" = "infra" ]; then
  if [ "$ASSIGN_ROLES" != "true" ]; then
    cat > "$OUTDIR/admin-role-commands.sh" <<EOF
# Run by an administrator with role-assignment rights on resource group $RG (two scoped assignments):
az role assignment create --assignee-object-id $PID --assignee-principal-type ServicePrincipal --role "Storage Blob Data Contributor" --scope $SID
az role assignment create --assignee-object-id $PID --assignee-principal-type ServicePrincipal --role "Key Vault Secrets User" --scope $KID
# Store the Oxylabs key yourself (never in chat); you need "Key Vault Secrets Officer" on $KV:
az keyvault secret set --vault-name $KV --name oxylabs-webapi-key --value "<YOUR-OXYLABS-KEY>"
EOF
    echo "Phase 1 done. Send $OUTDIR/admin-role-commands.sh to the administrator, then run phase 'job'."
  else
    echo "Phase 1 done (roles assigned). Store the key if not given: az keyvault secret set --vault-name $KV --name oxylabs-webapi-key --value <key>"
  fi
else
  JOB=$(get jobName)
  az containerapp job show -g "$RG" -n "$JOB" --query "{name:name,cron:properties.configuration.scheduleTriggerConfig.cronExpression}" -o json | tee "$OUTDIR/job.json"
  echo "Phase 2 done. Job $JOB runs on '$CRON' (UTC). Start now: az containerapp job start -g $RG -n $JOB"
fi
