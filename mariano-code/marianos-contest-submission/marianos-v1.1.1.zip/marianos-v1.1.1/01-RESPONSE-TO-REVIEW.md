# Mariano's #69 → v1.1.1: response to the review and to your answers

Package: `marianos-scraper-1.1.1-src.zip`, `code_sha256 = 268b672e28873599357b42b45703f670b5a7e1655b5ed71f5f4ae0ae13b92f42`
(SOURCE_FINGERPRINT.txt inside the ZIP also lists the SHA-256 of every config file and of requirements.txt).
Status words: **DONE (code + offline tests)** = implemented and tested on saved real marianos.com responses;
**PENDING LIVE** = needs a fresh live run, blocked by the items in §6.

## A. Your answers on v1.1.0 → what v1.1.1 changes (all offline-tested; nothing run live)

**Azure** – understood: no role yet, nothing to assume. v1.1.1 keeps the Contributor-only path you chose:
`deploy/azure/preflight.sh` (read-only) → `deploy.sh <sub> scraper-contest-asif-test infra` → your administrator runs
the two scoped managed-identity role assignments from `admin-role-commands.sh` → `deploy.sh … job`. Resources are
created only after you approve the deployment/cost plan; the location follows the resource group (West US 2).
Outputs go to the private Blob container in that group. The job deploys **MANUAL** (no unattended schedule); the
twice-weekly cron is a parameter (`SCHEDULE=on`, `CRON`) to be activated only after you approve days/time.
Planned resources: Container Apps environment + 1 job (0.5 vCPU / 1 GiB, consumption), Storage Standard_LRS (Blob +
5 GB Azure Files), Key Vault standard, Log Analytics (30-day retention), user-assigned managed identity.

**Coverage – zero unexplained gaps** (`src/mscraper/coverage.py`): for every seed request every count Mariano's
reported is kept with its response SHA-256 (`observed_totals`); the gap (`max(reported, brand-slice sum) − distinct
products read`) is split into explained items – `request_not_completed`, `reported_total_capped`,
`slice_not_completed`, `slice_exceeds_page`, `brands_not_discovered`, `site_count_inconsistent` – each with its
evidence. A request is `complete` only when proven; validation **fails** on any unexplained gap and never counts an
incomplete request as complete (tests `test_coverage_reconciliation_complete_and_gap`,
`test_coverage_keeps_changing_counts_and_detects_unexplained_gaps`). The earlier 19/99 figure and the checkpoint
continuation are not presented as coverage or recovery.

**Stores** – Crystal Lake 53100544 / 60014 stays labelled as such. Vernon Hills (1720 N Milwaukee Ave, IL 60061) is
added as **candidate** `53100502` (from the public store page URL …/531/00502), disabled and unverified until
`verify-store` shows id, ZIP, address, IN_STORE modality and store-sourced prices from Mariano's own responses.
Results are always labelled from the responses; a test proves one store's settings against another store's
responses fail verification and collect nothing (`test_store_results_are_never_relabelled`). The store of every
live run will be named to you before it starts.

**Coupons** – `09-COUPONS-missing-linkage-and-dependency.md`: the exact missing linkage (coupon → qualifying UPCs and
per-product quantity, clip, eligibility, limit, validity, price), where it lives, what the current provider cannot
do (verified), and the proposed dependency (browser path first, account only if needed) – nothing assumed or
charged. Missing values stay empty strings; no PPM or coupon price is calculated.

**Quota / plan / window** – `10-TEST-PLAN-bounded-tests-endpoint-window.md`: compatible endpoint (Oxylabs Web Scraper
API, Kroger target, `webapi.oxylabs.io/v1/scrape/kroger`, Bearer key, store_id per request; an adapter for the classic
`realtime.oxylabs.io` username/password endpoint is included and must pass Test 1 first). Bounded tests with hard caps
enforced in code: **Test 1 ≤ 19 requests** (verify both stores + probe), **Test 2 ≤ 300 requests** (Batteries + Light
Bulbs end to end); Test 3 sized from Test 2. Proposed window: a weekday 09:00-09:30 CT (Test 1) and 10:00-11:00 CT
(Test 2) – exact date proposed once access and quota are confirmed.

---

## 1. Retention – DONE (code + offline tests) · live evidence PENDING LIVE
* `src/mscraper/parse.py → map_product`: the `no_price` and `no_upc` rejections are removed.
  * no store price → the row is kept with `regular_price`, `sale_price`, `ppm` = `""`; `observations.json` records
    `availability: no_store_price` (test `test_product_without_store_price_is_kept_with_empty_price_fields`)
  * no UPC → the row is kept with `upc: ""`; identity `product:<Mariano's product id>`, stored as
    `source_product_id` / `identity_source: data.id` in observations.json, never in `upc`; the product URL keeps the
    source id (test `test_product_without_upc_keeps_product_id_out_of_the_upc_field`)
* The `item.upc or prod.id` fallback is removed. Evidence: in all 240 products of the saved real responses
  `item.upc` = the product key = `data.id`, and a top-level `prod.id` does not exist – the fallback could never fire
  (test `test_upc_only_from_item_upc_and_equals_product_key_in_real_data`).
* Carried observations: `src/mscraper/retention.py`. A product of the last published dataset that a run does not return
  is output unchanged, with its own last `crawl_date`; `observations.json` marks `status: carried`, `last_observed`,
  `last_observed_run`, `carried_since`; fresh rows have `status: fresh`, `first_observed`. Carried indefinitely
  (tests `test_carry_forward_keeps_missing_products_with_their_own_dates`,
  `test_second_run_carries_products_it_did_not_see`).
* Validation measures price completeness only over priced rows and UPC completeness only over rows that carry a UPC,
  so kept unavailable products can never make a run fail or disappear.

## 2. Weight filtering – DONE (code + offline tests)
* `exclude_sold_by_weight` is removed from settings and code.
* `parse.approximate_weight_trigger` excludes only when Mariano's own displayed size or price wording is approximate /
  estimated. Real case: sold-by-weight steaks are displayed as `"about $10.39 each"` (item `weightPerUnit 0.8 lb`) –
  that wording excludes them; every exclusion is written to `exclusions.json` with the field and exact text.
* A product sold by weight with an exact displayed price is kept (test `test_sold_by_weight_alone_never_excludes`);
  titles such as "(About 3 Steaks per Pack)" do not trigger anything (`test_title_count_phrase_is_not_an_approximate_weight`);
  bulk / family-pack / multipack sizes are preserved exactly as displayed and are never treated as promotions
  (`test_family_pack_label_is_not_a_volume_deal`).
* Setting `crawl.approximate_weight_price_wording` (default true) controls whether price wording counts; size wording
  always counts.

## 3. Coverage – CODE DONE · NOT YET PROVEN LIVE (PENDING LIVE)
* Root cause (measured 21 Oct, saved in tests/fixtures): Mariano's server-rendered search returns the first 24 results of
  a request for every page number (page 2 = the same 24 UPCs, ranks renumbered 25-48).
* v1.1.0 partitions every seed request (each shelf's own name and parts) that reports more than it returned with
  Mariano's own `brandName` filter (the parameter its menu links use). Slices are disjoint (one brand per product).
* `coverage.json` (machine-readable) reconciles, per seed request: Mariano's reported total, distinct products read
  (request + all brand slices), `gap`, `complete`, open slices, and `reported_total_is_capped` (Mariano's shows at most
  "1,000"; such totals are never counted as complete). Expansion requests are listed separately and are not counted
  as proof. Summary per shelf and category.
* A slice whose response is not filtered to its brand is failed and never counted (`test_ignored_brand_filter_is_never_counted_as_coverage`).
* No production caps: `max_queries_per_shelf: 0`, `max_brand_slices_per_request: 0`; `--limit` is for demo only and a
  demo run is never published.
* What must still be proven live: that `query + brandName` is honored for every shelf, and the final gap figures.
  First step: `python -m mscraper probe --location marianos-544-crystal-lake --query Batteries` (≈ 10-15 requests;
  page 1 vs 2, JS-rendered page 2, every brand slice of page 1, with evidence files).
* Reconciliation of what was already delivered (`07-coverage-reconciliation-v1.0.0-runs.json`, generated by
  `tools/reconcile_v100_runs.py` from the runs' own checkpoints): entry #69 = 99 requests, 19 provably complete,
  7 with Mariano's capped "1,000" total, Batteries gap 97 (121 reported, 24 read), Light Bulbs gap 76 (100 / 24),
  22 of the 27 product CSV rows not in that run. The stopped run cf40b8: 85 of 573 requests fetched.
* Known limits, reported not hidden: /pl/ product-list pages are not served by the provider, so a sub-category's own
  total cannot be read – completeness is proven per request; a brand never seen in any page of a shelf cannot be
  sliced and remains in that request's gap.

## 4. Offers – volume terms DONE · digital association partly obtainable, dependency stated
* Volume: wording preserved + the terms of the same Mariano's object appended, e.g.
  `Save $1 each when you buy 5 or more (valid 2026-10-07T00:00:00Z to 2026-10-27T23:59:59Z; applies to: in-store)`;
  multi-buy prices `2 For $5.00 (valid until 2026-10-28T03:59:59Z)` with `volume_deals_price 5.00`. Every offer is also
  kept structured in `observations.json → offers` (kind, text, template, displayed price, valid_from, valid_to,
  modalities, limit, source path). No price is ever calculated; a family-pack label is never a promotion.
* Digital, obtainable now: Mariano's own search filter `savings=Coupons` (verified live 21 Oct: request variables
  `savings: ["Coupons"]`, products returned) identifies products that have a digital coupon. v1.1.0 runs one filtered
  request per shelf and records `digital_coupon_available` with the evidence response SHA-256 in observations.json.
  The `digital_deals_*` fields stay empty unless the terms are shown, so nothing is invented.
* Exact dependency for full product ↔ coupon terms: the coupon's qualifying products are loaded by the Mariano's web
  app after page load (the "Shop All Items" button opens a script-driven modal; anonymous visitors see "Sign In To
  Clip"). They are not in the server HTML. The current provider endpoint (Oxylabs Web Scraper API, Kroger) accepts no
  cookies, headers or page actions (verified: HTTP 400 UNSUPPORTED_BODY_PROPERTY) and does not serve product detail
  pages (/p/, HTTP 500 after its retries in 4 tests). Needed: a browser path that can click "Shop All Items" (a
  provider with page actions, or a self-hosted browser on a US proxy) and, for clip-required terms, a Mariano's
  customer account. The 24 coupons with full displayed wording, restrictions (e.g. "PICKUP OR DELIVERY ONLY") and
  expiry are already collected in coupons.json.

## 5. Provenance / testing – DONE (code, offline) · live evidence PENDING LIVE
* Every page used: `ledger.json` row (time, kind, URL, SHA-256 + size of the exact response, store and request
  location id, active modality, products listed / priced, `sourceLocationId`s of its prices) and
  `evidence/pages/<sha256>.json.gz` – the price-bearing excerpt (store details, request variables, every product with
  its price block); full raw HTML for the first pages per category. Every output row's `observations.response_sha256`
  points to its page, so each row can be verified independently.
* `report.json → provenance`: code SHA-256, every config file SHA-256, requirements SHA-256, Python, argv – at start,
  at every resume, at finish.
* Version / run reconciliation: `02-CHANGELOG-and-run-reconciliation.md` (code at collection, revalidation, query
  expansion, quota stop, 23-Oct resume attempt).
* Resume: run fa0c1b's second session was a checkpoint continuation of a finished run (completed requests reused,
  only new work fetched) – not a crash recovery. A live kill-and-resume that completes, live failed-publication proof
  and unattended Azure executions are PENDING LIVE (§6). Offline tests are labeled separately (`04-offline-tests-v1.1.0.txt`).

## 6. Blockers (exact)
1. Oxylabs: the shared trial key answers `HTTP 429 QUOTA_EXCEEDED` (last checked 2026-10-24). Usage and the quota still
   needed: `03-oxylabs-usage-quota-and-cost.md`.
2. Azure: no role assignment yet on scraper-contest-asif-test (your confirmation); checked again 2026-10-24 – the
   subscription is not visible to debugging.specialist@gmail.com. Waiting for your confirmation.

## 7. Azure – ready for your limited test access
* `deploy/azure/preflight.sh <subscription> <rg>` – read-only: my roles on the resource group, provider registration,
  existing resources; changes nothing.
* `deploy/azure/deploy.sh <subscription> <rg> infra` then `... job` – deploys into your EXISTING resource group only
  (never creates resource groups, needs no subscription rights). With Contributor only, it writes
  `admin-role-commands.sh`: two role assignments scoped to the new storage account and Key Vault, plus the command
  for you to store the Oxylabs key in Key Vault yourself. Tags and schedule are parameters.
* `deploy/azure/collect_evidence.sh <subscription> <rg>` – read-only proof of unattended execution: job schedule, every
  execution, run log events from Log Analytics, published latest/ files, every run report, checksums.
